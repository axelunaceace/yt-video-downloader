# ⚡ AceBlade Downloader

A polished, modern desktop YouTube downloader for Linux/Ubuntu.

**Features**

- Paste any YouTube URL (watch, youtu.be, Shorts)
- Download video as MP4 (best quality, merged with FFmpeg)
- Download audio as MP3 (128 / 192 / 256 / 320 kbps)
- Real-time progress: %, speed, size, ETA
- Cancel downloads safely
- Video info preview before downloading
- Download history
- Beautiful dark UI
- First-launch dependency installer (yt-dlp + FFmpeg via apt)
- Uses the **yt-dlp command-line executable** (no `import yt_dlp`)

---

## Requirements

| Component   | Notes                                      |
|-------------|--------------------------------------------|
| Python 3.8+ | Tested on 3.10 / 3.12                      |
| Tkinter     | `python3-tk` on Debian/Ubuntu              |
| yt-dlp      | System executable (`which yt-dlp`)         |
| FFmpeg      | Required for merging & MP3 conversion      |

---

## Quick Start (Ubuntu / Debian)

```bash
# 1. Install system packages
sudo apt update
sudo apt install -y python3 python3-tk yt-dlp ffmpeg

# 2. Clone / copy the project
cd aceblade-downloader

# 3. Run
python3 main.py
```

On first launch the app will verify dependencies.  
If anything is missing it shows a clean setup window and can install packages for you (may ask for your password).

---

## Why not `import yt_dlp`?

Many systems (especially Ubuntu with PEP 668) have the `yt-dlp` **binary** installed via apt while the Python module is unavailable or blocked by the externally-managed-environment rule.

AceBlade therefore always calls the executable:

```python
subprocess.Popen(["yt-dlp", "--no-playlist", ...])
```

This works whether yt-dlp was installed by apt, pipx, or any other PATH method.

---

## Project Structure

```
aceblade-downloader/
├── main.py                 # Entry point
├── requirements.txt
├── README.md
├── app/
│   ├── __init__.py
│   ├── gui.py              # Main window + dialogs
│   ├── downloader.py       # yt-dlp subprocess wrapper
│   ├── dependencies.py     # Check / install yt-dlp & FFmpeg
│   ├── settings.py
│   ├── history.py
│   ├── theme.py            # Centralized dark theme
│   └── utils.py
├── assets/                 # Optional logo / icons
├── data/
│   ├── settings.json       # Created at runtime
│   └── history.json
└── logs/
    └── aceblade.log
```

---

## Keyboard Shortcuts

| Shortcut        | Action              |
|-----------------|---------------------|
| `Ctrl + V`      | Paste URL           |
| `Enter`         | Fetch video info    |
| `Ctrl + Enter`  | Start download      |
| `Esc`           | Cancel / close popup|

---

## Settings

- Default download folder
- Remember last mode (Video / Audio)
- MP3 quality (128–320 kbps)
- Custom paths for yt-dlp and FFmpeg
- Maximum filename length (avoids “File name too long” errors)

---

## Optional: Deno (JS runtime)

Modern yt-dlp may warn:

```
No supported JavaScript runtime could be found
```

This is **not fatal**. Most videos still download.  
For maximum format availability you can install Deno:

```bash
curl -fsSL https://deno.land/install.sh | sh
```

AceBlade shows a non-blocking status message when the runtime is missing.

---

## Troubleshooting

**“yt-dlp not found”**  
```bash
sudo apt install -y yt-dlp
# or
pipx install yt-dlp
```

**“FFmpeg not found”**  
```bash
sudo apt install -y ffmpeg
```

**Filename too long**  
AceBlade already sanitizes titles and falls back to the video ID.  
You can lower the limit in Settings → Advanced.

**PEP 668 / externally-managed-environment**  
Do **not** rely on `pip install --user yt-dlp`.  
Use the system package or pipx instead. AceBlade never needs the Python module.

---

## License

MIT – use freely.
