#!/usr/bin/env python3
"""
AceBlade Downloader – entry point.

Usage:
    python3 main.py

The application checks for yt-dlp and FFmpeg on first launch and offers
to install them via apt on Ubuntu/Debian. It never requires the
yt_dlp Python package – the system yt-dlp executable is used via
subprocess.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the project root is on sys.path
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    from app.utils import logger, setup_logging
    from app.dependencies import check_all
    from app.gui import run_setup_then_main, run_main_directly

    setup_logging()
    logger.info("=" * 50)
    logger.info("AceBlade Downloader starting")
    logger.info("Python %s", sys.version)

    # Fast path: if everything is already present, skip setup UI
    try:
        result = check_all()
        if result.all_ok:
            logger.info("All dependencies present – launching main UI")
            run_main_directly()
        else:
            logger.info("Missing dependencies: %s – showing setup", result.missing_names)
            run_setup_then_main()
    except Exception as e:
        logger.exception("Fatal error during startup")
        print(f"Fatal error: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
