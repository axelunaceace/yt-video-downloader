#!/usr/bin/env python3
"""
⚡ AceBlade Downloader — Single-file YouTube downloader for Linux/Ubuntu
=======================================================================
Uses the yt-dlp *executable* via subprocess (never imports yt_dlp).
Works with apt / pipx / PATH installations. PEP 668 safe.

Usage:
    python3 aceblade_downloader.py

System deps (Ubuntu/Debian):
    sudo apt install -y python3 python3-tk yt-dlp ffmpeg
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import tkinter as tk
from tkinter import filedialog, ttk

# ============================================================================
# Paths & constants
# ============================================================================

APP_NAME = "AceBlade Downloader"
APP_VERSION = "1.0.0"
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
LOGS_DIR = APP_DIR / "logs"
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
LOG_FILE = LOGS_DIR / "aceblade.log"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

MAX_HISTORY = 50


# ============================================================================
# Theme
# ============================================================================

class Theme:
    BG = "#0B0F19"
    CARD = "#111827"
    CARD_SECONDARY = "#172033"
    CARD_HOVER = "#1E293B"
    INPUT_BG = "#0F172A"
    BORDER = "#1E293B"
    BORDER_FOCUS = "#6366F1"
    ACCENT = "#6366F1"
    ACCENT_HOVER = "#818CF8"
    TEXT = "#F8FAFC"
    TEXT_SECONDARY = "#94A3B8"
    TEXT_MUTED = "#64748B"
    SUCCESS = "#22C55E"
    ERROR = "#EF4444"
    WARNING = "#F59E0B"
    PROGRESS_BG = "#1E293B"
    PROGRESS_FILL = "#6366F1"
    FONT_TITLE = ("Segoe UI", 22, "bold")
    FONT_HEADING = ("Segoe UI", 14, "bold")
    FONT_SUBHEADING = ("Segoe UI", 12, "bold")
    FONT_BODY = ("Segoe UI", 11)
    FONT_SMALL = ("Segoe UI", 10)
    FONT_TINY = ("Segoe UI", 9)
    FONT_BUTTON = ("Segoe UI", 11, "bold")
    FONT_MONO_SMALL = ("DejaVu Sans Mono", 10)
    SETUP_WIDTH, SETUP_HEIGHT = 520, 460
    MAIN_WIDTH, MAIN_HEIGHT = 920, 680
    MIN_WIDTH, MIN_HEIGHT = 780, 580


# ============================================================================
# Logging
# ============================================================================

def setup_logging() -> logging.Logger:
    logger = logging.getLogger("aceblade")
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    return logger


logger = setup_logging()


# ============================================================================
# Utilities
# ============================================================================

YOUTUBE_PATTERNS = [
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/watch\?v=([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtu\.be/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/shorts/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/embed/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/v/([\w-]{11})"),
]


def is_valid_youtube_url(url: str) -> bool:
    if not url or not isinstance(url, str):
        return False
    url = url.strip()
    if not (url.startswith("http://") or url.startswith("https://")):
        return False
    return any(p.search(url) for p in YOUTUBE_PATTERNS)


def extract_video_id(url: str) -> Optional[str]:
    if not url:
        return None
    for pattern in YOUTUBE_PATTERNS:
        m = pattern.search(url)
        if m:
            return m.group(1)
    try:
        qs = parse_qs(urlparse(url).query)
        if "v" in qs and re.match(r"^[\w-]{11}$", qs["v"][0]):
            return qs["v"][0]
    except Exception:
        pass
    return None


def sanitize_filename(name: str, max_length: int = 80) -> str:
    if not name:
        return "video"
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name)
    name = re.sub(r"\s+", " ", name).strip()
    if len(name) > max_length:
        name = name[:max_length].rstrip()
    return name or "video"


def format_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "--:--"
    try:
        seconds = int(float(seconds))
    except (TypeError, ValueError):
        return "--:--"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def format_bytes(num: Optional[float]) -> str:
    if num is None:
        return "—"
    try:
        num = float(num)
    except (TypeError, ValueError):
        return "—"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num) < 1024.0:
            return f"{num:.1f} {unit}" if unit != "B" else f"{int(num)} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"


def format_speed(bps: Optional[float]) -> str:
    if bps is None or bps <= 0:
        return "—"
    return format_bytes(bps) + "/s"


def format_eta(seconds: Optional[float]) -> str:
    if seconds is None or seconds < 0:
        return "—"
    try:
        seconds = int(float(seconds))
    except (TypeError, ValueError):
        return "—"
    if seconds < 60:
        return f"00:{seconds:02d}"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m:02d}:{s:02d}"
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def load_json(path: Path, default: Any = None) -> Any:
    if default is None:
        default = {}
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        logger.warning("Failed to load %s: %s", path, e)
    return default


def save_json(path: Path, data: Any) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        logger.error("Failed to save %s: %s", path, e)
        return False


def open_folder(path: str | Path) -> None:
    path = str(path)
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        logger.warning("Could not open folder %s: %s", path, e)


def default_download_dir() -> str:
    home = Path.home()
    downloads = home / "Downloads"
    return str(downloads) if downloads.is_dir() else str(home)


# ============================================================================
# Settings
# ============================================================================

DEFAULT_SETTINGS: Dict[str, Any] = {
    "general": {
        "download_folder": default_download_dir(),
        "last_mode": "video",
    },
    "audio": {"quality": "192"},
    "advanced": {
        "ytdlp_path": "",
        "ffmpeg_path": "",
        "max_filename_length": 80,
    },
}


class Settings:
    def __init__(self) -> None:
        self._data: Dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        stored = load_json(SETTINGS_FILE, {})
        self._data = self._merge(DEFAULT_SETTINGS, stored)

    def save(self) -> bool:
        return save_json(SETTINGS_FILE, self._data)

    def _merge(self, defaults: Dict, stored: Dict) -> Dict:
        result = {}
        for key, default_val in defaults.items():
            if key in stored and isinstance(default_val, dict) and isinstance(stored[key], dict):
                result[key] = self._merge(default_val, stored[key])
            elif key in stored:
                result[key] = stored[key]
            else:
                result[key] = default_val
        return result

    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self._data.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        if section not in self._data:
            self._data[section] = {}
        self._data[section][key] = value

    @property
    def download_folder(self) -> str:
        return self.get("general", "download_folder", default_download_dir())

    @download_folder.setter
    def download_folder(self, value: str) -> None:
        self.set("general", "download_folder", value)

    @property
    def last_mode(self) -> str:
        return self.get("general", "last_mode", "video")

    @last_mode.setter
    def last_mode(self, value: str) -> None:
        self.set("general", "last_mode", value)

    @property
    def audio_quality(self) -> str:
        return self.get("audio", "quality", "192")

    @audio_quality.setter
    def audio_quality(self, value: str) -> None:
        self.set("audio", "quality", value)

    @property
    def max_filename_length(self) -> int:
        return int(self.get("advanced", "max_filename_length", 80))

    @property
    def ytdlp_path(self) -> str:
        return self.get("advanced", "ytdlp_path", "") or ""

    @property
    def ffmpeg_path(self) -> str:
        return self.get("advanced", "ffmpeg_path", "") or ""


# ============================================================================
# History
# ============================================================================

class History:
    def __init__(self) -> None:
        self._entries: List[Dict[str, Any]] = []
        self.load()

    def load(self) -> None:
        data = load_json(HISTORY_FILE, {"entries": []})
        self._entries = data.get("entries", [])
        if not isinstance(self._entries, list):
            self._entries = []

    def save(self) -> bool:
        return save_json(HISTORY_FILE, {"entries": self._entries})

    def add(
        self,
        title: str,
        mode: str,
        filepath: str,
        size_bytes: Optional[int] = None,
        video_id: str = "",
    ) -> None:
        entry = {
            "title": title or "Unknown",
            "mode": mode,
            "filepath": filepath,
            "size_bytes": size_bytes,
            "video_id": video_id,
            "timestamp": time.time(),
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        self._entries.insert(0, entry)
        self._entries = self._entries[:MAX_HISTORY]
        self.save()

    def get_recent(self, limit: int = 10) -> List[Dict[str, Any]]:
        return self._entries[:limit]

    @staticmethod
    def relative_date(ts: float) -> str:
        diff = time.time() - ts
        if diff < 60:
            return "Just now"
        if diff < 3600:
            return f"{int(diff / 60)} min ago"
        if diff < 86400:
            return f"{int(diff / 3600)}h ago"
        if diff < 172800:
            return "Yesterday"
        days = int(diff / 86400)
        if days < 7:
            return f"{days} days ago"
        return datetime.fromtimestamp(ts).strftime("%b %d, %Y")


# ============================================================================
# Dependencies
# ============================================================================

class DepStatus(Enum):
    OK = "ok"
    MISSING = "missing"
    CHECKING = "checking"
    INSTALLING = "installing"
    FAILED = "failed"


@dataclass
class Dependency:
    name: str
    status: DepStatus = DepStatus.CHECKING
    version: str = ""
    message: str = ""


@dataclass
class CheckResult:
    all_ok: bool
    dependencies: List[Dependency] = field(default_factory=list)
    missing_names: List[str] = field(default_factory=list)


def _run_cmd(args: List[str], timeout: int = 30) -> Tuple[int, str, str]:
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except FileNotFoundError:
        return 127, "", "command not found"
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


def check_python() -> Dependency:
    dep = Dependency(name="Python", status=DepStatus.OK)
    dep.version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info < (3, 8):
        dep.status = DepStatus.FAILED
        dep.message = "Python 3.8+ required"
    else:
        dep.message = f"Python {dep.version}"
    return dep


def check_tkinter() -> Dependency:
    dep = Dependency(name="Tkinter", status=DepStatus.OK)
    try:
        import tkinter as _tk
        dep.version = str(_tk.TkVersion)
        dep.message = f"Tk {dep.version}"
    except ImportError:
        dep.status = DepStatus.MISSING
        dep.message = "Tkinter not available"
    return dep


def get_ytdlp_executable(custom_path: str = "") -> Optional[str]:
    if custom_path and os.path.isfile(custom_path) and os.access(custom_path, os.X_OK):
        return custom_path
    path = which("yt-dlp")
    if path:
        return path
    for c in ("/usr/bin/yt-dlp", "/usr/local/bin/yt-dlp", os.path.expanduser("~/.local/bin/yt-dlp")):
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def get_ffmpeg_executable(custom_path: str = "") -> Optional[str]:
    if custom_path and os.path.isfile(custom_path) and os.access(custom_path, os.X_OK):
        return custom_path
    path = which("ffmpeg")
    if path:
        return path
    for c in ("/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg"):
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def check_ytdlp(custom_path: str = "") -> Dependency:
    dep = Dependency(name="yt-dlp", status=DepStatus.CHECKING)
    path = get_ytdlp_executable(custom_path)
    if not path:
        dep.status = DepStatus.MISSING
        dep.message = "yt-dlp not found in PATH"
        return dep
    code, out, err = _run_cmd([path, "--version"], timeout=15)
    if code == 0 and out:
        dep.status = DepStatus.OK
        dep.version = out.split("\n")[0].strip()
        dep.message = f"yt-dlp {dep.version}"
    else:
        dep.status = DepStatus.MISSING
        dep.message = err or "yt-dlp not executable"
    return dep


def check_ffmpeg(custom_path: str = "") -> Dependency:
    dep = Dependency(name="FFmpeg", status=DepStatus.CHECKING)
    path = get_ffmpeg_executable(custom_path)
    if not path:
        dep.status = DepStatus.MISSING
        dep.message = "ffmpeg not found in PATH"
        return dep
    code, out, err = _run_cmd([path, "-version"], timeout=15)
    if code == 0:
        first = (out or err).split("\n")[0]
        version = ""
        parts = first.split()
        for i, p in enumerate(parts):
            if p.lower() == "version" and i + 1 < len(parts):
                version = parts[i + 1]
                break
        dep.status = DepStatus.OK
        dep.version = version
        dep.message = f"FFmpeg {version}" if version else "FFmpeg found"
    else:
        dep.status = DepStatus.MISSING
        dep.message = err or "ffmpeg not executable"
    return dep


def check_all(ytdlp_path: str = "", ffmpeg_path: str = "") -> CheckResult:
    deps = [check_python(), check_tkinter(), check_ytdlp(ytdlp_path), check_ffmpeg(ffmpeg_path)]
    missing = [d.name for d in deps if d.status != DepStatus.OK]
    return CheckResult(all_ok=len(missing) == 0, dependencies=deps, missing_names=missing)


def _is_debian_based() -> bool:
    return os.path.isfile("/etc/debian_version") or which("apt-get") is not None


def install_package_apt(
    package: str,
    progress_cb: Optional[Callable[[str, float], None]] = None,
) -> Tuple[bool, str]:
    if not _is_debian_based():
        return False, "Automatic installation only on Debian/Ubuntu"

    def upd(msg: str, prog: float = 0.0) -> None:
        if progress_cb:
            progress_cb(msg, prog)
        logger.info(msg)

    upd("Updating package lists…", 0.1)
    code, out, err = _run_cmd(["sudo", "-n", "apt-get", "update", "-qq"], timeout=120)
    if code != 0:
        upd("Requesting administrator privileges…", 0.15)
        code, out, err = _run_cmd(["sudo", "apt-get", "update", "-qq"], timeout=180)
        if code != 0:
            return False, f"apt update failed: {err or out}"

    upd(f"Installing {package}…", 0.4)
    code, out, err = _run_cmd(["sudo", "apt-get", "install", "-y", package], timeout=300)
    if code != 0:
        return False, f"Failed to install {package}: {err or out}"
    upd(f"{package} installed", 1.0)
    return True, f"{package} installed"


def install_missing(
    missing: List[str],
    progress_cb: Optional[Callable[[str, float], None]] = None,
) -> Tuple[bool, str]:
    pkg_map = {"yt-dlp": "yt-dlp", "FFmpeg": "ffmpeg", "Tkinter": "python3-tk"}
    results = []
    total = len(missing)
    for i, name in enumerate(missing):
        base = i / max(total, 1)

        def scaled(msg: str, p: float, b=base) -> None:
            if progress_cb:
                progress_cb(msg, b + p / max(total, 1))

        pkg = pkg_map.get(name)
        if pkg:
            ok, msg = install_package_apt(pkg, scaled)
        else:
            ok, msg = False, f"Cannot auto-install {name}"
        results.append((name, ok, msg))

    failed = [r for r in results if not r[1]]
    if failed:
        return False, "; ".join(f"{n}: {m}" for n, _, m in failed)
    return True, "All dependencies installed"


def check_js_runtime() -> Tuple[bool, str]:
    for cmd in ("deno", "node", "nodejs"):
        path = which(cmd)
        if path:
            code, out, _ = _run_cmd([path, "--version"], timeout=10)
            if code == 0:
                return True, f"{cmd} {out.split()[0] if out else ''}".strip()
    return False, ""


# ============================================================================
# Downloader (subprocess yt-dlp)
# ============================================================================

class DownloadState(Enum):
    IDLE = "idle"
    FETCHING_INFO = "fetching_info"
    DOWNLOADING = "downloading"
    POSTPROCESSING = "postprocessing"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ERROR = "error"


@dataclass
class VideoInfo:
    id: str = ""
    title: str = ""
    uploader: str = ""
    duration: Optional[float] = None
    thumbnail: str = ""
    webpage_url: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration_str(self) -> str:
        return format_duration(self.duration)


@dataclass
class ProgressInfo:
    percent: float = 0.0
    downloaded_bytes: Optional[float] = None
    total_bytes: Optional[float] = None
    speed: Optional[float] = None
    eta: Optional[float] = None
    status: str = ""

    @property
    def percent_str(self) -> str:
        return f"{self.percent:.1f}%"

    @property
    def size_str(self) -> str:
        return f"{format_bytes(self.downloaded_bytes)} / {format_bytes(self.total_bytes)}"

    @property
    def speed_str(self) -> str:
        return format_speed(self.speed)

    @property
    def eta_str(self) -> str:
        return format_eta(self.eta)


class Downloader:
    def __init__(
        self,
        ytdlp_path: str = "",
        ffmpeg_path: str = "",
        max_filename_length: int = 80,
    ) -> None:
        self.ytdlp_path = ytdlp_path
        self.ffmpeg_path = ffmpeg_path
        self.max_filename_length = max_filename_length
        self._process: Optional[subprocess.Popen] = None
        self._state = DownloadState.IDLE
        self._cancel_requested = False
        self.on_progress: Optional[Callable[[ProgressInfo], None]] = None
        self.on_state: Optional[Callable[[DownloadState, str], None]] = None
        self.on_info: Optional[Callable[[Optional[VideoInfo], Optional[str]], None]] = None

    @property
    def state(self) -> DownloadState:
        return self._state

    def _set_state(self, state: DownloadState, message: str = "") -> None:
        self._state = state
        logger.debug("State → %s | %s", state.value, message)
        if self.on_state:
            try:
                self.on_state(state, message)
            except Exception as e:
                logger.warning("on_state error: %s", e)

    def _resolve_ytdlp(self) -> str:
        path = get_ytdlp_executable(self.ytdlp_path)
        if not path:
            raise RuntimeError("yt-dlp executable not found. Please install yt-dlp.")
        return path

    def _resolve_ffmpeg(self) -> Optional[str]:
        return get_ffmpeg_executable(self.ffmpeg_path)

    def fetch_info(self, url: str) -> None:
        if not is_valid_youtube_url(url):
            if self.on_info:
                self.on_info(None, "Invalid YouTube URL")
            return

        def worker() -> None:
            self._set_state(DownloadState.FETCHING_INFO, "Fetching video info…")
            try:
                info = self._fetch_info_sync(url)
                if self.on_info:
                    self.on_info(info, None)
                self._set_state(DownloadState.IDLE, "")
            except Exception as e:
                logger.exception("fetch_info failed")
                if self.on_info:
                    self.on_info(None, str(e))
                self._set_state(DownloadState.ERROR, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _fetch_info_sync(self, url: str) -> VideoInfo:
        ytdlp = self._resolve_ytdlp()
        args = [
            ytdlp, "--dump-json", "--no-download", "--no-playlist",
            "--no-warnings", "--flat-playlist", url,
        ]
        result = subprocess.run(args, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            if "ERROR:" in err:
                err = err.split("ERROR:")[-1].strip()
            raise RuntimeError(err[:300])
        data = json.loads(result.stdout)
        if "entries" in data and data["entries"]:
            data = data["entries"][0] or data
        return VideoInfo(
            id=data.get("id") or extract_video_id(url) or "",
            title=data.get("title") or data.get("fulltitle") or "Unknown",
            uploader=data.get("uploader") or data.get("channel") or "",
            duration=data.get("duration"),
            thumbnail=data.get("thumbnail") or "",
            webpage_url=data.get("webpage_url") or url,
            raw=data,
        )

    def download(
        self,
        url: str,
        output_dir: str,
        mode: str = "video",
        audio_quality: str = "192",
        video_info: Optional[VideoInfo] = None,
    ) -> None:
        if self._state in (DownloadState.DOWNLOADING, DownloadState.POSTPROCESSING):
            return
        if not is_valid_youtube_url(url):
            self._set_state(DownloadState.ERROR, "Invalid YouTube URL")
            return
        self._cancel_requested = False

        def worker() -> None:
            try:
                self._download_sync(url, output_dir, mode, audio_quality, video_info)
            except Exception as e:
                if self._cancel_requested:
                    self._set_state(DownloadState.CANCELLED, "Download cancelled")
                else:
                    logger.exception("Download failed")
                    self._set_state(DownloadState.ERROR, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _download_sync(
        self,
        url: str,
        output_dir: str,
        mode: str,
        audio_quality: str,
        video_info: Optional[VideoInfo],
    ) -> None:
        ytdlp = self._resolve_ytdlp()
        ffmpeg = self._resolve_ffmpeg()
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        video_id = (video_info.id if video_info else None) or extract_video_id(url) or "video"
        safe_title = ""
        if video_info and video_info.title:
            safe_title = sanitize_filename(video_info.title, self.max_filename_length)

        if safe_title:
            out_template = os.path.join(output_dir, f"{safe_title}-[{video_id}].%(ext)s")
        else:
            out_template = os.path.join(output_dir, f"{video_id}.%(ext)s")

        args: List[str] = [
            ytdlp, "--no-playlist", "--newline", "--progress", "-o", out_template,
        ]
        if ffmpeg:
            args.extend(["--ffmpeg-location", os.path.dirname(ffmpeg) or ffmpeg])

        if mode == "audio":
            args.extend(["-x", "--audio-format", "mp3", "--audio-quality", audio_quality, "-f", "bestaudio/best"])
        else:
            args.extend(["-f", "bv*+ba/b", "--merge-output-format", "mp4"])

        args.append(url)
        logger.info("Starting download: %s", " ".join(args))
        self._set_state(DownloadState.DOWNLOADING, "Starting download…")

        self._process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
            preexec_fn=os.setsid if os.name != "nt" else None,
        )

        final_path: Optional[str] = None
        progress = ProgressInfo()

        try:
            assert self._process.stdout is not None
            for line in self._process.stdout:
                if self._cancel_requested:
                    break
                line = line.rstrip()
                if not line:
                    continue
                if "No supported JavaScript runtime" in line:
                    logger.warning("JS runtime warning from yt-dlp")
                    continue
                parsed = self._parse_progress_line(line)
                if parsed:
                    progress = parsed
                    if self.on_progress:
                        try:
                            self.on_progress(progress)
                        except Exception:
                            pass
                    continue
                if "[download] Destination:" in line:
                    final_path = line.split("Destination:", 1)[-1].strip()
                elif "[ExtractAudio]" in line or "[Merger]" in line or "Merging" in line:
                    self._set_state(DownloadState.POSTPROCESSING, "Post-processing…")
                elif line.startswith("ERROR:"):
                    raise RuntimeError(line.replace("ERROR:", "").strip()[:400])
            returncode = self._process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            returncode = self._process.poll() or -1
        finally:
            self._process = None

        if self._cancel_requested:
            self._cleanup_part_files(output_dir, video_id)
            self._set_state(DownloadState.CANCELLED, "Download cancelled")
            return
        if returncode != 0:
            raise RuntimeError(f"yt-dlp exited with code {returncode}")

        if not final_path or not os.path.isfile(final_path):
            final_path = self._find_output_file(output_dir, video_id, mode)

        progress.percent = 100.0
        progress.status = "Completed"
        if self.on_progress:
            self.on_progress(progress)
        self._set_state(DownloadState.COMPLETED, final_path or "Download completed")
        logger.info("Download completed: %s", final_path)

    def cancel(self) -> None:
        self._cancel_requested = True
        proc = self._process
        if proc and proc.poll() is None:
            logger.info("Cancelling download (pid=%s)", proc.pid)
            try:
                if os.name != "nt":
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                else:
                    proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    if os.name != "nt":
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    else:
                        proc.kill()
            except Exception as e:
                logger.warning("Error while cancelling: %s", e)
        self._set_state(DownloadState.CANCELLED, "Download cancelled")

    def _parse_progress_line(self, line: str) -> Optional[ProgressInfo]:
        if "[download]" not in line:
            return None
        if "Destination:" in line or "has already been downloaded" in line:
            return None
        info = ProgressInfo(status="Downloading")
        m = re.search(r"(\d+\.?\d*)%", line)
        if m:
            info.percent = float(m.group(1))
        m = re.search(r"of\s+~?\s*([\d.]+)\s*([KMGT]?i?B)", line, re.IGNORECASE)
        if m:
            info.total_bytes = self._to_bytes(float(m.group(1)), m.group(2))
        m = re.search(r"(\d+\.?\d*)\s*([KMGT]?i?B)\s+of", line, re.IGNORECASE)
        if m:
            info.downloaded_bytes = self._to_bytes(float(m.group(1)), m.group(2))
        elif info.total_bytes is not None and info.percent > 0:
            info.downloaded_bytes = info.total_bytes * (info.percent / 100.0)
        m = re.search(r"at\s+([\d.]+)\s*([KMGT]?i?B)/s", line, re.IGNORECASE)
        if m:
            info.speed = self._to_bytes(float(m.group(1)), m.group(2))
        m = re.search(r"ETA\s+(\d+:\d+(?::\d+)?)", line)
        if m:
            info.eta = self._eta_to_seconds(m.group(1))
        return info

    @staticmethod
    def _to_bytes(value: float, unit: str) -> float:
        unit = unit.upper().replace("I", "")
        mult = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
        return value * mult.get(unit, 1)

    @staticmethod
    def _eta_to_seconds(eta: str) -> float:
        parts = [int(p) for p in eta.split(":")]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        return float(parts[0]) if parts else 0.0

    def _find_output_file(self, output_dir: str, video_id: str, mode: str) -> Optional[str]:
        ext = "mp3" if mode == "audio" else "mp4"
        candidates = []
        try:
            for name in os.listdir(output_dir):
                if video_id in name and name.endswith(f".{ext}"):
                    path = os.path.join(output_dir, name)
                    candidates.append((os.path.getmtime(path), path))
            if candidates:
                candidates.sort(reverse=True)
                return candidates[0][1]
        except OSError:
            pass
        return None

    def _cleanup_part_files(self, output_dir: str, video_id: str) -> None:
        try:
            for name in os.listdir(output_dir):
                if video_id in name and (name.endswith(".part") or name.endswith(".ytdl")):
                    try:
                        os.remove(os.path.join(output_dir, name))
                    except OSError:
                        pass
        except OSError:
            pass


# ============================================================================
# GUI widgets
# ============================================================================

class RoundedButton(tk.Canvas):
    def __init__(
        self, parent, text: str = "", command: Optional[Callable] = None,
        bg: str = Theme.ACCENT, fg: str = Theme.TEXT, hover_bg: str = Theme.ACCENT_HOVER,
        width: int = 120, height: int = 36, font=None, **kwargs,
    ):
        parent_bg = Theme.BG
        try:
            parent_bg = parent.cget("bg")
        except Exception:
            pass
        super().__init__(parent, width=width, height=height, bg=parent_bg, highlightthickness=0, **kwargs)
        self._text = text
        self._command = command
        self._bg = bg
        self._fg = fg
        self._hover_bg = hover_bg
        self._width = width
        self._height = height
        self._font = font or Theme.FONT_BUTTON
        self._enabled = True
        self._draw(bg)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color: str) -> None:
        self.delete("all")
        r, w, h = 8, self._width, self._height
        self.create_rectangle(r, 0, w - r, h, fill=color, outline="")
        self.create_rectangle(0, r, w, h - r, fill=color, outline="")
        self.create_oval(0, 0, 2 * r, 2 * r, fill=color, outline="")
        self.create_oval(w - 2 * r, 0, w, 2 * r, fill=color, outline="")
        self.create_oval(0, h - 2 * r, 2 * r, h, fill=color, outline="")
        self.create_oval(w - 2 * r, h - 2 * r, w, h, fill=color, outline="")
        self.create_text(w // 2, h // 2, text=self._text, fill=self._fg, font=self._font)

    def _on_enter(self, _=None) -> None:
        if self._enabled:
            self._draw(self._hover_bg)

    def _on_leave(self, _=None) -> None:
        if self._enabled:
            self._draw(self._bg)

    def _on_click(self, _=None) -> None:
        if self._enabled and self._command:
            self._command()

    def set_text(self, text: str) -> None:
        self._text = text
        self._draw(self._bg if self._enabled else Theme.TEXT_MUTED)

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        self._draw(self._bg if enabled else Theme.CARD_SECONDARY)


class ModeCard(tk.Frame):
    def __init__(
        self, parent, title: str, subtitle: str, icon: str, mode: str,
        selected: bool = False, on_select: Optional[Callable[[str], None]] = None, **kwargs,
    ):
        super().__init__(parent, bg=Theme.CARD, **kwargs)
        self.mode = mode
        self._selected = selected
        self._on_select = on_select
        self.configure(highlightbackground=Theme.BORDER, highlightthickness=1)
        self.bind("<Button-1>", self._clicked)

        inner = tk.Frame(self, bg=Theme.CARD, padx=16, pady=14)
        inner.pack(fill="both", expand=True)
        inner.bind("<Button-1>", self._clicked)

        self.icon_lbl = tk.Label(inner, text=icon, font=("Segoe UI", 20), bg=Theme.CARD, fg=Theme.ACCENT)
        self.icon_lbl.pack(anchor="w")
        self.icon_lbl.bind("<Button-1>", self._clicked)

        self.title_lbl = tk.Label(inner, text=title, font=Theme.FONT_SUBHEADING, bg=Theme.CARD, fg=Theme.TEXT)
        self.title_lbl.pack(anchor="w", pady=(4, 0))
        self.title_lbl.bind("<Button-1>", self._clicked)

        self.sub_lbl = tk.Label(inner, text=subtitle, font=Theme.FONT_SMALL, bg=Theme.CARD, fg=Theme.TEXT_SECONDARY)
        self.sub_lbl.pack(anchor="w")
        self.sub_lbl.bind("<Button-1>", self._clicked)
        self._apply_style()

    def _clicked(self, _=None) -> None:
        if self._on_select:
            self._on_select(self.mode)

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        self._apply_style()

    def _apply_style(self) -> None:
        bg = Theme.CARD_SECONDARY if self._selected else Theme.CARD
        border = Theme.ACCENT if self._selected else Theme.BORDER
        thick = 2 if self._selected else 1
        self.configure(highlightbackground=border, highlightthickness=thick, bg=bg)
        for w in (self, self.icon_lbl, self.title_lbl, self.sub_lbl):
            try:
                w.configure(bg=bg)
            except Exception:
                pass
        self.icon_lbl.configure(fg=Theme.ACCENT if self._selected else Theme.TEXT_SECONDARY)


class ProgressBar(tk.Canvas):
    def __init__(self, parent, width: int = 400, height: int = 8, **kwargs):
        super().__init__(parent, width=width, height=height, bg=Theme.PROGRESS_BG, highlightthickness=0, **kwargs)
        self._width = width
        self._height = height
        self._value = 0.0
        self._draw()

    def set(self, value: float) -> None:
        self._value = max(0.0, min(100.0, value))
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        self.create_rectangle(0, 0, self._width, self._height, fill=Theme.PROGRESS_BG, outline="")
        fill_w = int(self._width * (self._value / 100.0))
        if fill_w > 0:
            self.create_rectangle(0, 0, fill_w, self._height, fill=Theme.PROGRESS_FILL, outline="")


# ============================================================================
# Dialogs
# ============================================================================

class BaseDialog(tk.Toplevel):
    def __init__(self, parent, title: str = "", width: int = 400, height: int = 280):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=Theme.BG)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - width) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.bind("<Escape>", lambda e: self.destroy())


class SuccessDialog(BaseDialog):
    def __init__(self, parent, filename: str = "", folder: str = ""):
        super().__init__(parent, "Download Complete", 420, 300)
        self.folder = folder
        tk.Label(self, text="✓", font=("Segoe UI", 36), bg=Theme.BG, fg=Theme.SUCCESS).pack(pady=(24, 4))
        tk.Label(self, text="Download Complete!", font=Theme.FONT_HEADING, bg=Theme.BG, fg=Theme.TEXT).pack()
        tk.Label(
            self, text="Your file was downloaded successfully.",
            font=Theme.FONT_BODY, bg=Theme.BG, fg=Theme.TEXT_SECONDARY,
        ).pack(pady=(4, 12))
        if filename:
            tk.Label(
                self, text=os.path.basename(filename), font=Theme.FONT_SMALL,
                bg=Theme.BG, fg=Theme.ACCENT, wraplength=360,
            ).pack(pady=(0, 16))
        btn_frame = tk.Frame(self, bg=Theme.BG)
        btn_frame.pack(pady=8)
        RoundedButton(btn_frame, text="Open Folder", command=self._open, bg=Theme.ACCENT, hover_bg=Theme.ACCENT_HOVER, width=130, height=36).pack(side="left", padx=6)
        RoundedButton(btn_frame, text="Close", command=self.destroy, bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=100, height=36).pack(side="left", padx=6)

    def _open(self) -> None:
        if self.folder:
            open_folder(self.folder)
        self.destroy()


class ErrorDialog(BaseDialog):
    def __init__(self, parent, title: str = "Error", message: str = "", details: str = ""):
        height = 320 if details else 260
        super().__init__(parent, title, 440, height)
        tk.Label(self, text="⚠", font=("Segoe UI", 32), bg=Theme.BG, fg=Theme.ERROR).pack(pady=(20, 4))
        tk.Label(self, text=title, font=Theme.FONT_HEADING, bg=Theme.BG, fg=Theme.TEXT).pack()
        tk.Label(
            self, text=message, font=Theme.FONT_BODY, bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY, wraplength=380, justify="center",
        ).pack(pady=(8, 8))
        self._details = details
        self._details_visible = False
        self._details_frame = None
        if details:
            self._toggle_btn = RoundedButton(
                self, text="Show Details", command=self._toggle_details,
                bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=130, height=30, font=Theme.FONT_SMALL,
            )
            self._toggle_btn.pack(pady=4)
        RoundedButton(self, text="Close", command=self.destroy, bg=Theme.ACCENT, hover_bg=Theme.ACCENT_HOVER, width=100, height=36).pack(pady=(12, 0))

    def _toggle_details(self) -> None:
        if self._details_visible:
            if self._details_frame:
                self._details_frame.destroy()
                self._details_frame = None
            self._toggle_btn.set_text("Show Details")
            self._details_visible = False
        else:
            self._details_frame = tk.Frame(self, bg=Theme.CARD)
            self._details_frame.pack(fill="x", padx=20, pady=8)
            txt = tk.Text(
                self._details_frame, height=4, bg=Theme.INPUT_BG, fg=Theme.TEXT_SECONDARY,
                font=Theme.FONT_MONO_SMALL, wrap="word", relief="flat", highlightthickness=0,
            )
            txt.pack(fill="x", padx=4, pady=4)
            txt.insert("1.0", self._details)
            txt.configure(state="disabled")
            self._toggle_btn.set_text("Hide Details")
            self._details_visible = True


class SettingsDialog(BaseDialog):
    def __init__(self, parent, settings: Settings, on_save: Callable[[], None]):
        super().__init__(parent, "Settings", 480, 480)
        self.settings = settings
        self.on_save = on_save
        self._build()

    def _build(self) -> None:
        frame = tk.Frame(self, bg=Theme.BG)
        frame.pack(fill="both", expand=True, padx=16, pady=12)

        self._section(frame, "General")
        self.folder_var = tk.StringVar(value=self.settings.download_folder)
        self._labeled_entry(frame, "Download folder", self.folder_var)
        RoundedButton(
            frame, text="Browse…", command=self._browse_folder,
            bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=100, height=28, font=Theme.FONT_SMALL,
        ).pack(anchor="e", padx=8, pady=2)

        self.mode_var = tk.StringVar(value=self.settings.last_mode)
        self._labeled_option(frame, "Default mode", self.mode_var, ["video", "audio"])

        self._section(frame, "Audio")
        self.audio_q_var = tk.StringVar(value=self.settings.audio_quality)
        self._labeled_option(frame, "MP3 quality (kbps)", self.audio_q_var, ["128", "192", "256", "320"])

        self._section(frame, "Advanced")
        self.ytdlp_var = tk.StringVar(value=self.settings.ytdlp_path)
        self._labeled_entry(frame, "yt-dlp path (empty = auto)", self.ytdlp_var)
        self.ffmpeg_var = tk.StringVar(value=self.settings.ffmpeg_path)
        self._labeled_entry(frame, "FFmpeg path (empty = auto)", self.ffmpeg_var)
        self.maxlen_var = tk.StringVar(value=str(self.settings.max_filename_length))
        self._labeled_entry(frame, "Max filename length", self.maxlen_var)

        RoundedButton(
            self, text="Save", command=self._save,
            bg=Theme.ACCENT, hover_bg=Theme.ACCENT_HOVER, width=120, height=36,
        ).pack(pady=12)

    def _section(self, parent, title: str) -> None:
        tk.Label(parent, text=title, font=Theme.FONT_SUBHEADING, bg=Theme.BG, fg=Theme.ACCENT).pack(anchor="w", padx=8, pady=(12, 4))

    def _labeled_entry(self, parent, label: str, var: tk.StringVar) -> None:
        tk.Label(parent, text=label, font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(anchor="w", padx=8)
        tk.Entry(
            parent, textvariable=var, bg=Theme.INPUT_BG, fg=Theme.TEXT, insertbackground=Theme.TEXT,
            relief="flat", font=Theme.FONT_BODY, highlightthickness=1,
            highlightbackground=Theme.BORDER, highlightcolor=Theme.BORDER_FOCUS,
        ).pack(fill="x", padx=8, pady=(2, 6), ipady=4)

    def _labeled_option(self, parent, label: str, var: tk.StringVar, values: List[str]) -> None:
        tk.Label(parent, text=label, font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(anchor="w", padx=8)
        ttk.OptionMenu(parent, var, var.get(), *values).pack(anchor="w", padx=8, pady=(2, 6))

    def _browse_folder(self) -> None:
        path = filedialog.askdirectory(initialdir=self.folder_var.get() or os.path.expanduser("~"))
        if path:
            self.folder_var.set(path)

    def _save(self) -> None:
        self.settings.download_folder = self.folder_var.get().strip()
        self.settings.last_mode = self.mode_var.get()
        self.settings.audio_quality = self.audio_q_var.get()
        self.settings.set("advanced", "ytdlp_path", self.ytdlp_var.get().strip())
        self.settings.set("advanced", "ffmpeg_path", self.ffmpeg_var.get().strip())
        try:
            self.settings.set("advanced", "max_filename_length", int(self.maxlen_var.get()))
        except ValueError:
            pass
        self.settings.save()
        self.on_save()
        self.destroy()


# ============================================================================
# Setup window
# ============================================================================

class SetupWindow(tk.Toplevel):
    def __init__(self, parent, on_complete: Callable[[], None]):
        super().__init__(parent)
        self.on_complete = on_complete
        self.title("AceBlade – Setup")
        self.configure(bg=Theme.BG)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        w, h = Theme.SETUP_WIDTH, Theme.SETUP_HEIGHT
        self.geometry(f"{w}x{h}")
        self.update_idletasks()
        x = (self.winfo_screenwidth() - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self._deps: List[Dependency] = []
        self._installing = False
        self._build_ui()
        self.after(200, self._start_check)

    def _build_ui(self) -> None:
        tk.Label(self, text="⚡ ACEBLADE", font=("Segoe UI", 24, "bold"), bg=Theme.BG, fg=Theme.ACCENT).pack(pady=(28, 0))
        tk.Label(self, text="DOWNLOADER", font=("Segoe UI", 14, "bold"), bg=Theme.BG, fg=Theme.TEXT).pack()
        tk.Label(self, text="Preparing your environment", font=Theme.FONT_BODY, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(pady=(16, 12))
        card = tk.Frame(self, bg=Theme.CARD, padx=20, pady=14)
        card.pack(fill="x", padx=40)
        self.dep_frame = tk.Frame(card, bg=Theme.CARD)
        self.dep_frame.pack(fill="x")
        self.status_lbl = tk.Label(self, text="Checking dependencies…", font=Theme.FONT_BODY, bg=Theme.BG, fg=Theme.TEXT_SECONDARY)
        self.status_lbl.pack(pady=(16, 6))
        self.progress = ProgressBar(self, width=360, height=10)
        self.progress.pack(pady=4)
        self.hint_lbl = tk.Label(self, text="Please wait…", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_MUTED)
        self.hint_lbl.pack(pady=(8, 0))

    def _render_deps(self) -> None:
        for w in self.dep_frame.winfo_children():
            w.destroy()
        icons = {DepStatus.OK: "✓", DepStatus.MISSING: "○", DepStatus.CHECKING: "⟳", DepStatus.INSTALLING: "⟳", DepStatus.FAILED: "✗"}
        colors = {DepStatus.OK: Theme.SUCCESS, DepStatus.MISSING: Theme.TEXT_MUTED, DepStatus.CHECKING: Theme.ACCENT, DepStatus.INSTALLING: Theme.ACCENT, DepStatus.FAILED: Theme.ERROR}
        for dep in self._deps:
            row = tk.Frame(self.dep_frame, bg=Theme.CARD)
            row.pack(fill="x", pady=3)
            icon = icons.get(dep.status, "○")
            color = colors.get(dep.status, Theme.TEXT_MUTED)
            tk.Label(row, text=f"  {icon}  {dep.name}", font=Theme.FONT_BODY, bg=Theme.CARD, fg=color, anchor="w").pack(side="left")
            if dep.version:
                tk.Label(row, text=dep.version, font=Theme.FONT_TINY, bg=Theme.CARD, fg=Theme.TEXT_MUTED).pack(side="right")

    def _start_check(self) -> None:
        def worker() -> None:
            result = check_all()
            self.after(0, lambda: self._on_check_done(result))
        threading.Thread(target=worker, daemon=True).start()

    def _on_check_done(self, result: CheckResult) -> None:
        self._deps = result.dependencies
        self._render_deps()
        if result.all_ok:
            self.status_lbl.configure(text="All dependencies ready", fg=Theme.SUCCESS)
            self.progress.set(100)
            self.hint_lbl.configure(text="Launching…")
            self.after(800, self._finish)
        else:
            self.status_lbl.configure(text=f"Installing missing: {', '.join(result.missing_names)}", fg=Theme.WARNING)
            self.hint_lbl.configure(text="Administrator privileges may be required")
            self.after(400, lambda: self._start_install(result.missing_names))

    def _start_install(self, missing: List[str]) -> None:
        self._installing = True

        def progress_cb(msg: str, prog: float) -> None:
            self.after(0, lambda: self._update_progress(msg, prog))

        def worker() -> None:
            ok, summary = install_missing(missing, progress_cb)
            self.after(0, lambda: self._on_install_done(ok, summary))

        threading.Thread(target=worker, daemon=True).start()

    def _update_progress(self, msg: str, prog: float) -> None:
        self.status_lbl.configure(text=msg)
        self.progress.set(prog * 100)

    def _on_install_done(self, ok: bool, summary: str) -> None:
        self._installing = False
        if ok:
            result = check_all()
            self._deps = result.dependencies
            self._render_deps()
            if result.all_ok:
                self.status_lbl.configure(text="Setup complete!", fg=Theme.SUCCESS)
                self.progress.set(100)
                self.hint_lbl.configure(text="Launching…")
                self.after(900, self._finish)
            else:
                self.status_lbl.configure(text="Some dependencies still missing", fg=Theme.ERROR)
                self.hint_lbl.configure(text=summary[:80])
                self._show_manual_hint()
        else:
            self.status_lbl.configure(text="Installation failed", fg=Theme.ERROR)
            self.hint_lbl.configure(text=summary[:100])
            self._show_manual_hint()

    def _show_manual_hint(self) -> None:
        tip = "Please install manually:\n  sudo apt update && sudo apt install -y yt-dlp ffmpeg python3-tk"
        tk.Label(self, text=tip, font=Theme.FONT_TINY, bg=Theme.BG, fg=Theme.TEXT_MUTED, justify="left").pack(pady=8)
        RoundedButton(
            self, text="Continue Anyway", command=self._finish,
            bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=150, height=32,
        ).pack(pady=4)

    def _finish(self) -> None:
        self.destroy()
        self.on_complete()

    def _on_close(self) -> None:
        if self._installing:
            return
        self.destroy()
        self.on_complete()


# ============================================================================
# Main application
# ============================================================================

class MainApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("⚡ AceBlade Downloader")
        self.configure(bg=Theme.BG)
        self.minsize(Theme.MIN_WIDTH, Theme.MIN_HEIGHT)
        self.geometry(f"{Theme.MAIN_WIDTH}x{Theme.MAIN_HEIGHT}")
        self.update_idletasks()
        x = (self.winfo_screenwidth() - Theme.MAIN_WIDTH) // 2
        y = (self.winfo_screenheight() - Theme.MAIN_HEIGHT) // 2
        self.geometry(f"+{x}+{y}")

        self.settings = Settings()
        self.history = History()
        self.downloader = Downloader(
            ytdlp_path=self.settings.ytdlp_path,
            ffmpeg_path=self.settings.ffmpeg_path,
            max_filename_length=self.settings.max_filename_length,
        )
        self.downloader.on_progress = self._on_progress
        self.downloader.on_state = self._on_state
        self.downloader.on_info = self._on_info

        self._mode = self.settings.last_mode
        self._video_info: Optional[VideoInfo] = None
        self._placeholder = "🔗  Paste your YouTube URL…"

        self._build_ui()
        self._bind_shortcuts()
        self._refresh_history()
        self.after(1500, self._check_js_runtime)
        logger.info("Main window ready")

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg=Theme.BG)
        header.pack(fill="x", padx=24, pady=(16, 4))
        tk.Label(header, text="⚡ AceBlade Downloader", font=Theme.FONT_TITLE, bg=Theme.BG, fg=Theme.TEXT).pack(side="left")
        RoundedButton(
            header, text="⚙ Settings", command=self._open_settings,
            bg=Theme.CARD, hover_bg=Theme.CARD_HOVER, width=110, height=32, font=Theme.FONT_SMALL,
        ).pack(side="right")

        tk.Label(
            self, text="Download anything you need  ·  Fast · Simple · Reliable",
            font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w", padx=24, pady=(0, 12))

        # URL
        url_frame = tk.Frame(self, bg=Theme.BG)
        url_frame.pack(fill="x", padx=24, pady=4)
        tk.Label(url_frame, text="YouTube URL", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        entry_row = tk.Frame(url_frame, bg=Theme.BG)
        entry_row.pack(fill="x", pady=(4, 0))

        self.url_var = tk.StringVar()
        self.url_entry = tk.Entry(
            entry_row, textvariable=self.url_var, bg=Theme.INPUT_BG, fg=Theme.TEXT,
            insertbackground=Theme.TEXT, relief="flat", font=Theme.FONT_BODY,
            highlightthickness=1, highlightbackground=Theme.BORDER, highlightcolor=Theme.BORDER_FOCUS,
        )
        self.url_entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 8))
        self._show_placeholder()
        self.url_entry.bind("<FocusIn>", self._clear_placeholder)
        self.url_entry.bind("<FocusOut>", self._show_placeholder)

        RoundedButton(entry_row, text="Paste", command=self._paste_url, bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=80, height=36).pack(side="left", padx=(0, 6))
        RoundedButton(entry_row, text="Fetch Info", command=self._fetch_info, bg=Theme.ACCENT, hover_bg=Theme.ACCENT_HOVER, width=100, height=36).pack(side="left")

        # Mode cards
        mode_frame = tk.Frame(self, bg=Theme.BG)
        mode_frame.pack(fill="x", padx=24, pady=16)
        self.video_card = ModeCard(mode_frame, title="VIDEO", subtitle="MP4  ·  Best quality", icon="🎬", mode="video", selected=self._mode == "video", on_select=self._select_mode)
        self.video_card.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.audio_card = ModeCard(mode_frame, title="AUDIO", subtitle="MP3  ·  192 kbps", icon="🎵", mode="audio", selected=self._mode == "audio", on_select=self._select_mode)
        self.audio_card.pack(side="left", fill="both", expand=True, padx=(8, 0))

        # Location
        loc_frame = tk.Frame(self, bg=Theme.BG)
        loc_frame.pack(fill="x", padx=24, pady=4)
        tk.Label(loc_frame, text="Download location", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        loc_row = tk.Frame(loc_frame, bg=Theme.BG)
        loc_row.pack(fill="x", pady=(4, 0))
        self.folder_var = tk.StringVar(value=self.settings.download_folder)
        tk.Entry(
            loc_row, textvariable=self.folder_var, bg=Theme.INPUT_BG, fg=Theme.TEXT,
            insertbackground=Theme.TEXT, relief="flat", font=Theme.FONT_BODY,
            highlightthickness=1, highlightbackground=Theme.BORDER, highlightcolor=Theme.BORDER_FOCUS,
        ).pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 8))
        RoundedButton(loc_row, text="Browse", command=self._browse_folder, bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=90, height=34).pack(side="left")

        # Info card
        self.info_card = tk.Frame(self, bg=Theme.CARD, padx=12, pady=10)
        self.thumb_label = tk.Label(self.info_card, text="🎬", font=("Segoe UI", 28), bg=Theme.CARD, fg=Theme.ACCENT)
        self.thumb_label.pack(side="left", padx=(4, 12))
        info_text = tk.Frame(self.info_card, bg=Theme.CARD)
        info_text.pack(side="left", fill="both", expand=True)
        self.info_title = tk.Label(info_text, text="", font=Theme.FONT_SUBHEADING, bg=Theme.CARD, fg=Theme.TEXT, anchor="w", wraplength=500, justify="left")
        self.info_title.pack(anchor="w")
        self.info_meta = tk.Label(info_text, text="", font=Theme.FONT_SMALL, bg=Theme.CARD, fg=Theme.TEXT_SECONDARY, anchor="w")
        self.info_meta.pack(anchor="w", pady=(4, 0))

        # Download / Cancel
        self.download_btn = RoundedButton(self, text="↓  DOWNLOAD", command=self._start_download, bg=Theme.ACCENT, hover_bg=Theme.ACCENT_HOVER, width=280, height=48, font=("Segoe UI", 13, "bold"))
        self.download_btn.pack(pady=16)
        self.cancel_btn = RoundedButton(self, text="Cancel", command=self._cancel_download, bg=Theme.ERROR, hover_bg="#DC2626", width=120, height=36)

        # Progress
        prog_frame = tk.Frame(self, bg=Theme.BG)
        prog_frame.pack(fill="x", padx=24, pady=4)
        tk.Label(prog_frame, text="Download Progress", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        self.progress_bar = ProgressBar(prog_frame, width=860, height=10)
        self.progress_bar.pack(fill="x", pady=(6, 4))
        self.progress_lbl = tk.Label(prog_frame, text="Ready", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_MUTED, anchor="w")
        self.progress_lbl.pack(fill="x")

        # History
        hist_header = tk.Frame(self, bg=Theme.BG)
        hist_header.pack(fill="x", padx=24, pady=(16, 4))
        tk.Label(hist_header, text="Recent Downloads", font=Theme.FONT_SUBHEADING, bg=Theme.BG, fg=Theme.TEXT).pack(side="left")
        self.history_frame = tk.Frame(self, bg=Theme.BG)
        self.history_frame.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self.status_bar = tk.Label(self, text="Ready", font=Theme.FONT_TINY, bg=Theme.CARD, fg=Theme.TEXT_MUTED, anchor="w", padx=12, pady=4)
        self.status_bar.pack(side="bottom", fill="x")

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-v>", lambda e: self._paste_url())
        self.bind("<Control-V>", lambda e: self._paste_url())
        self.bind("<Return>", lambda e: self._fetch_info())
        self.bind("<Control-Return>", lambda e: self._start_download())
        self.bind("<Escape>", lambda e: self._cancel_download())

    def _show_placeholder(self, _=None) -> None:
        if not self.url_var.get():
            self.url_entry.configure(fg=Theme.TEXT_MUTED)
            self.url_var.set(self._placeholder)

    def _clear_placeholder(self, _=None) -> None:
        if self.url_var.get() == self._placeholder:
            self.url_var.set("")
            self.url_entry.configure(fg=Theme.TEXT)

    def _get_url(self) -> str:
        url = self.url_var.get().strip()
        return "" if url == self._placeholder else url

    def _paste_url(self) -> None:
        try:
            clip = self.clipboard_get()
            if clip:
                self._clear_placeholder()
                self.url_var.set(clip.strip())
                self.url_entry.configure(fg=Theme.TEXT)
        except tk.TclError:
            pass

    def _select_mode(self, mode: str) -> None:
        self._mode = mode
        self.video_card.set_selected(mode == "video")
        self.audio_card.set_selected(mode == "audio")
        q = self.settings.audio_quality
        self.audio_card.sub_lbl.configure(text=f"MP3  ·  {q} kbps")

    def _browse_folder(self) -> None:
        path = filedialog.askdirectory(initialdir=self.folder_var.get() or os.path.expanduser("~"))
        if path:
            self.folder_var.set(path)
            self.settings.download_folder = path
            self.settings.save()

    def _fetch_info(self) -> None:
        url = self._get_url()
        if not url:
            self._set_status("Please paste a YouTube URL first", error=True)
            return
        if not is_valid_youtube_url(url):
            self._set_status("Invalid YouTube URL", error=True)
            return
        self._set_status("Fetching video information…")
        self.downloader.fetch_info(url)

    def _start_download(self) -> None:
        url = self._get_url()
        if not url:
            self._set_status("Please paste a YouTube URL first", error=True)
            return
        if not is_valid_youtube_url(url):
            self._set_status("Invalid YouTube URL", error=True)
            return
        folder = self.folder_var.get().strip() or self.settings.download_folder
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder, exist_ok=True)
            except OSError as e:
                self._set_status(f"Cannot create folder: {e}", error=True)
                return
        self.settings.last_mode = self._mode
        self.settings.download_folder = folder
        self.settings.save()
        self.download_btn.pack_forget()
        self.cancel_btn.pack(pady=12)
        self.progress_bar.set(0)
        self.progress_lbl.configure(text="Starting…")
        self.downloader.download(
            url=url, output_dir=folder, mode=self._mode,
            audio_quality=self.settings.audio_quality, video_info=self._video_info,
        )

    def _cancel_download(self) -> None:
        if self.downloader.state in (DownloadState.DOWNLOADING, DownloadState.POSTPROCESSING):
            self.downloader.cancel()
            self._set_status("Cancelling…")

    def _open_settings(self) -> None:
        SettingsDialog(self, self.settings, on_save=self._on_settings_saved)

    def _on_settings_saved(self) -> None:
        self.folder_var.set(self.settings.download_folder)
        self.downloader.ytdlp_path = self.settings.ytdlp_path
        self.downloader.ffmpeg_path = self.settings.ffmpeg_path
        self.downloader.max_filename_length = self.settings.max_filename_length
        self._select_mode(self.settings.last_mode)
        self._set_status("Settings saved")

    def _on_progress(self, info: ProgressInfo) -> None:
        self.after(0, lambda: self._apply_progress(info))

    def _apply_progress(self, info: ProgressInfo) -> None:
        self.progress_bar.set(info.percent)
        parts = [info.percent_str, info.speed_str, info.size_str]
        if info.eta is not None:
            parts.append(f"{info.eta_str} left")
        text = "    ".join(p for p in parts if p and p != "—")
        self.progress_lbl.configure(text=text or info.status)
        self._set_status(info.status or "Downloading…")

    def _on_state(self, state: DownloadState, message: str) -> None:
        self.after(0, lambda: self._apply_state(state, message))

    def _apply_state(self, state: DownloadState, message: str) -> None:
        if state == DownloadState.COMPLETED:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_bar.set(100)
            self.progress_lbl.configure(text="Completed")
            filepath = message if message and os.path.isfile(message) else ""
            folder = self.folder_var.get()
            title = self._video_info.title if self._video_info else (os.path.basename(filepath) if filepath else "Download")
            size = os.path.getsize(filepath) if filepath and os.path.isfile(filepath) else None
            self.history.add(
                title=title, mode=self._mode, filepath=filepath or folder,
                size_bytes=size, video_id=self._video_info.id if self._video_info else "",
            )
            self._refresh_history()
            SuccessDialog(self, filename=filepath, folder=folder)
            self._set_status("Download complete")
        elif state == DownloadState.CANCELLED:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_lbl.configure(text="Cancelled")
            self._set_status("Download cancelled")
        elif state == DownloadState.ERROR:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_lbl.configure(text="Failed")
            self._set_status(message or "Download failed", error=True)
            ErrorDialog(self, title="Download Failed", message="Something went wrong while downloading.", details=message)
        elif state == DownloadState.DOWNLOADING:
            self._set_status("Downloading…")
        elif state == DownloadState.POSTPROCESSING:
            self._set_status("Post-processing (FFmpeg)…")
            self.progress_lbl.configure(text="Merging / converting…")
        elif state == DownloadState.FETCHING_INFO:
            self._set_status("Fetching video info…")

    def _on_info(self, info: Optional[VideoInfo], error: Optional[str]) -> None:
        self.after(0, lambda: self._apply_info(info, error))

    def _apply_info(self, info: Optional[VideoInfo], error: Optional[str]) -> None:
        if error:
            self._set_status(error, error=True)
            self.info_card.pack_forget()
            self._video_info = None
            return
        if not info:
            return
        self._video_info = info
        self.info_title.configure(text=info.title or "Unknown title")
        meta_parts = []
        if info.uploader:
            meta_parts.append(info.uploader)
        if info.duration is not None:
            meta_parts.append(f"⏱ {info.duration_str}")
        if info.id:
            meta_parts.append(f"ID: {info.id}")
        self.info_meta.configure(text="  ·  ".join(meta_parts))
        self.info_card.pack_forget()
        self.info_card.pack(fill="x", padx=24, pady=8)
        self._set_status(f"Ready: {info.title[:60]}")

    def _refresh_history(self) -> None:
        for w in self.history_frame.winfo_children():
            w.destroy()
        entries = self.history.get_recent(8)
        if not entries:
            tk.Label(self.history_frame, text="No downloads yet", font=Theme.FONT_SMALL, bg=Theme.BG, fg=Theme.TEXT_MUTED).pack(anchor="w")
            return
        for entry in entries:
            row = tk.Frame(self.history_frame, bg=Theme.CARD, padx=10, pady=6)
            row.pack(fill="x", pady=2)
            icon = "🎬" if entry.get("mode") == "video" else "🎵"
            tk.Label(row, text=icon, font=("Segoe UI", 14), bg=Theme.CARD, fg=Theme.ACCENT).pack(side="left", padx=(0, 8))
            text_frame = tk.Frame(row, bg=Theme.CARD)
            text_frame.pack(side="left", fill="x", expand=True)
            title = entry.get("title", "Unknown")[:55]
            tk.Label(text_frame, text=title, font=Theme.FONT_SMALL, bg=Theme.CARD, fg=Theme.TEXT, anchor="w").pack(anchor="w")
            rel = History.relative_date(entry.get("timestamp", 0))
            size = format_bytes(entry.get("size_bytes"))
            tk.Label(text_frame, text=f"{rel}  ·  {size}", font=Theme.FONT_TINY, bg=Theme.CARD, fg=Theme.TEXT_MUTED, anchor="w").pack(anchor="w")
            path = entry.get("filepath", "")
            if path and os.path.exists(path):
                RoundedButton(
                    row, text="Open",
                    command=lambda p=path: open_folder(os.path.dirname(p) if os.path.isfile(p) else p),
                    bg=Theme.CARD_SECONDARY, hover_bg=Theme.CARD_HOVER, width=60, height=26, font=Theme.FONT_TINY,
                ).pack(side="right")

    def _set_status(self, text: str, error: bool = False) -> None:
        self.status_bar.configure(text=text, fg=Theme.ERROR if error else Theme.TEXT_MUTED)

    def _check_js_runtime(self) -> None:
        ok, version = check_js_runtime()
        if not ok:
            self._set_status("⚠ Advanced YouTube extraction support unavailable (install Deno for best results)")
            logger.info("No JS runtime detected")
        else:
            logger.info("JS runtime: %s", version)


# ============================================================================
# Entry point
# ============================================================================

def main() -> int:
    setup_logging()
    logger.info("=" * 50)
    logger.info("%s v%s starting", APP_NAME, APP_VERSION)
    logger.info("Python %s", sys.version)

    try:
        result = check_all()
        if result.all_ok:
            logger.info("All dependencies present – launching main UI")
            app = MainApp()
            app.mainloop()
        else:
            logger.info("Missing dependencies: %s – showing setup", result.missing_names)
            root = tk.Tk()
            root.withdraw()

            def launch_main() -> None:
                try:
                    root.destroy()
                except Exception:
                    pass
                app = MainApp()
                app.mainloop()

            setup = SetupWindow(root, on_complete=launch_main)
            root.wait_window(setup)
    except Exception as e:
        logger.exception("Fatal error during startup")
        print(f"Fatal error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
