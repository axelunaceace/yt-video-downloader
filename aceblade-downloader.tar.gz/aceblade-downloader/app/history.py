"""Download history management."""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .utils import HISTORY_FILE, load_json, save_json, logger


MAX_HISTORY = 50


class History:
    """Local JSON-backed download history."""

    def __init__(self) -> None:
        self._entries: List[Dict[str, Any]] = []
        self.load()

    def load(self) -> None:
        data = load_json(HISTORY_FILE, {"entries": []})
        self._entries = data.get("entries", [])
        if not isinstance(self._entries, list):
            self._entries = []

    def save(self) -> bool:
        return save_json(HISTORY_FILE, {"entries": self._entries})

    def add(
        self,
        title: str,
        mode: str,
        filepath: str,
        size_bytes: Optional[int] = None,
        video_id: str = "",
    ) -> None:
        """Add a completed download to history."""
        entry = {
            "title": title or "Unknown",
            "mode": mode,  # video | audio
            "filepath": filepath,
            "size_bytes": size_bytes,
            "video_id": video_id,
            "timestamp": time.time(),
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        self._entries.insert(0, entry)
        # Trim
        self._entries = self._entries[:MAX_HISTORY]
        self.save()
        logger.info("History entry added: %s", title)

    def get_recent(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Return the most recent entries."""
        return self._entries[:limit]

    def clear(self) -> None:
        self._entries = []
        self.save()

    def remove(self, index: int) -> None:
        if 0 <= index < len(self._entries):
            self._entries.pop(index)
            self.save()

    @staticmethod
    def relative_date(ts: float) -> str:
        """Human-friendly relative date."""
        now = time.time()
        diff = now - ts
        if diff < 60:
            return "Just now"
        if diff < 3600:
            mins = int(diff / 60)
            return f"{mins} min ago"
        if diff < 86400:
            hours = int(diff / 3600)
            return f"{hours}h ago"
        if diff < 172800:
            return "Yesterday"
        days = int(diff / 86400)
        if days < 7:
            return f"{days} days ago"
        return datetime.fromtimestamp(ts).strftime("%b %d, %Y")
