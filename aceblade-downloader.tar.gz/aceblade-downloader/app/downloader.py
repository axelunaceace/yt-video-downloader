"""yt-dlp based downloader using subprocess (no Python module import)."""

from __future__ import annotations

import os
import re
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .dependencies import get_ffmpeg_executable, get_ytdlp_executable
from .utils import (
    extract_video_id,
    format_bytes,
    format_duration,
    format_eta,
    format_speed,
    is_valid_youtube_url,
    logger,
    sanitize_filename,
)


class DownloadState(Enum):
    IDLE = "idle"
    FETCHING_INFO = "fetching_info"
    DOWNLOADING = "downloading"
    POSTPROCESSING = "postprocessing"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ERROR = "error"


@dataclass
class VideoInfo:
    id: str = ""
    title: str = ""
    uploader: str = ""
    duration: Optional[float] = None
    thumbnail: str = ""
    description: str = ""
    webpage_url: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration_str(self) -> str:
        return format_duration(self.duration)


@dataclass
class ProgressInfo:
    percent: float = 0.0
    downloaded_bytes: Optional[float] = None
    total_bytes: Optional[float] = None
    speed: Optional[float] = None
    eta: Optional[float] = None
    status: str = ""
    filename: str = ""

    @property
    def percent_str(self) -> str:
        return f"{self.percent:.1f}%"

    @property
    def size_str(self) -> str:
        dl = format_bytes(self.downloaded_bytes)
        total = format_bytes(self.total_bytes)
        return f"{dl} / {total}"

    @property
    def speed_str(self) -> str:
        return format_speed(self.speed)

    @property
    def eta_str(self) -> str:
        return format_eta(self.eta)


# Callbacks
ProgressCallback = Callable[[ProgressInfo], None]
StateCallback = Callable[[DownloadState, str], None]
InfoCallback = Callable[[Optional[VideoInfo], Optional[str]], None]


class Downloader:
    """
    YouTube downloader that invokes the yt-dlp *executable* via subprocess.
    Never imports the yt_dlp Python package.
    """

    def __init__(
        self,
        ytdlp_path: str = "",
        ffmpeg_path: str = "",
        max_filename_length: int = 80,
    ) -> None:
        self.ytdlp_path = ytdlp_path
        self.ffmpeg_path = ffmpeg_path
        self.max_filename_length = max_filename_length

        self._process: Optional[subprocess.Popen] = None
        self._state = DownloadState.IDLE
        self._lock = threading.Lock()
        self._cancel_requested = False

        self.on_progress: Optional[ProgressCallback] = None
        self.on_state: Optional[StateCallback] = None
        self.on_info: Optional[InfoCallback] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def state(self) -> DownloadState:
        return self._state

    def _set_state(self, state: DownloadState, message: str = "") -> None:
        self._state = state
        logger.debug("State → %s | %s", state.value, message)
        if self.on_state:
            try:
                self.on_state(state, message)
            except Exception as e:
                logger.warning("on_state callback error: %s", e)

    def _resolve_ytdlp(self) -> str:
        path = get_ytdlp_executable(self.ytdlp_path)
        if not path:
            raise RuntimeError(
                "yt-dlp executable not found. Please install yt-dlp."
            )
        return path

    def _resolve_ffmpeg(self) -> Optional[str]:
        return get_ffmpeg_executable(self.ffmpeg_path)

    def fetch_info(self, url: str) -> None:
        """Fetch video metadata in a background thread (no download)."""
        if not is_valid_youtube_url(url):
            if self.on_info:
                self.on_info(None, "Invalid YouTube URL")
            return

        def worker() -> None:
            self._set_state(DownloadState.FETCHING_INFO, "Fetching video info…")
            try:
                info = self._fetch_info_sync(url)
                if self.on_info:
                    self.on_info(info, None)
                self._set_state(DownloadState.IDLE, "")
            except Exception as e:
                logger.exception("fetch_info failed")
                if self.on_info:
                    self.on_info(None, str(e))
                self._set_state(DownloadState.ERROR, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _fetch_info_sync(self, url: str) -> VideoInfo:
        ytdlp = self._resolve_ytdlp()
        # Use --dump-json --no-download --no-playlist
        args = [
            ytdlp,
            "--dump-json",
            "--no-download",
            "--no-playlist",
            "--no-warnings",
            "--flat-playlist",  # ignore playlist expansion
            url,
        ]
        logger.info("Fetching info: %s", " ".join(args))
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            # Clean common noise
            if "ERROR:" in err:
                err = err.split("ERROR:")[-1].strip()
            raise RuntimeError(err[:300])

        import json

        data = json.loads(result.stdout)
        # Handle playlist edge case – take first entry if needed
        if "entries" in data and data["entries"]:
            data = data["entries"][0] or data

        info = VideoInfo(
            id=data.get("id") or extract_video_id(url) or "",
            title=data.get("title") or data.get("fulltitle") or "Unknown",
            uploader=data.get("uploader") or data.get("channel") or "",
            duration=data.get("duration"),
            thumbnail=data.get("thumbnail") or "",
            description=(data.get("description") or "")[:500],
            webpage_url=data.get("webpage_url") or url,
            raw=data,
        )
        return info

    def download(
        self,
        url: str,
        output_dir: str,
        mode: str = "video",  # video | audio
        audio_quality: str = "192",
        video_info: Optional[VideoInfo] = None,
    ) -> None:
        """Start download in a background thread."""
        if self._state in (DownloadState.DOWNLOADING, DownloadState.POSTPROCESSING):
            logger.warning("Download already in progress")
            return

        if not is_valid_youtube_url(url):
            self._set_state(DownloadState.ERROR, "Invalid YouTube URL")
            return

        self._cancel_requested = False

        def worker() -> None:
            try:
                self._download_sync(
                    url, output_dir, mode, audio_quality, video_info
                )
            except Exception as e:
                if self._cancel_requested:
                    self._set_state(DownloadState.CANCELLED, "Download cancelled")
                else:
                    logger.exception("Download failed")
                    self._set_state(DownloadState.ERROR, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def _download_sync(
        self,
        url: str,
        output_dir: str,
        mode: str,
        audio_quality: str,
        video_info: Optional[VideoInfo],
    ) -> None:
        ytdlp = self._resolve_ytdlp()
        ffmpeg = self._resolve_ffmpeg()

        Path(output_dir).mkdir(parents=True, exist_ok=True)

        video_id = (video_info.id if video_info else None) or extract_video_id(url) or "video"
        safe_title = ""
        if video_info and video_info.title:
            safe_title = sanitize_filename(
                video_info.title, self.max_filename_length
            )

        # Preferred: id-based name to avoid "filename too long"
        if safe_title:
            out_template = os.path.join(
                output_dir, f"{safe_title}-[{video_id}].%(ext)s"
            )
        else:
            out_template = os.path.join(output_dir, f"{video_id}.%(ext)s")

        args: List[str] = [
            ytdlp,
            "--no-playlist",
            "--newline",
            "--progress",
            "-o",
            out_template,
        ]

        if ffmpeg:
            args.extend(["--ffmpeg-location", os.path.dirname(ffmpeg) or ffmpeg])

        if mode == "audio":
            args.extend(
                [
                    "-x",  # extract audio
                    "--audio-format",
                    "mp3",
                    "--audio-quality",
                    audio_quality,
                    "-f",
                    "bestaudio/best",
                ]
            )
        else:
            # Best video + best audio, merge to mp4
            args.extend(
                [
                    "-f",
                    "bv*+ba/b",
                    "--merge-output-format",
                    "mp4",
                ]
            )

        args.append(url)

        logger.info("Starting download: %s", " ".join(args))
        self._set_state(DownloadState.DOWNLOADING, "Starting download…")

        # Start process
        self._process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
            preexec_fn=os.setsid if os.name != "nt" else None,
        )

        final_path: Optional[str] = None
        progress = ProgressInfo()

        try:
            assert self._process.stdout is not None
            for line in self._process.stdout:
                if self._cancel_requested:
                    break
                line = line.rstrip()
                if not line:
                    continue

                # Detect JS runtime warning (non-fatal)
                if "No supported JavaScript runtime" in line:
                    logger.warning("JS runtime warning from yt-dlp")
                    continue

                parsed = self._parse_progress_line(line)
                if parsed:
                    progress = parsed
                    if self.on_progress:
                        try:
                            self.on_progress(progress)
                        except Exception:
                            pass
                    continue

                # Detect destination / post-processing
                if "[download] Destination:" in line:
                    final_path = line.split("Destination:", 1)[-1].strip()
                elif "[ExtractAudio]" in line or "[Merger]" in line or "Merging" in line:
                    self._set_state(
                        DownloadState.POSTPROCESSING, "Post-processing…"
                    )
                elif "Deleting original file" in line:
                    pass
                elif line.startswith("ERROR:"):
                    raise RuntimeError(line.replace("ERROR:", "").strip()[:400])

            returncode = self._process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            returncode = self._process.poll() or -1
        finally:
            self._process = None

        if self._cancel_requested:
            self._cleanup_part_files(output_dir, video_id)
            self._set_state(DownloadState.CANCELLED, "Download cancelled")
            return

        if returncode != 0:
            raise RuntimeError(
                f"yt-dlp exited with code {returncode}. Check logs for details."
            )

        # Try to locate the final file
        if not final_path or not os.path.isfile(final_path):
            final_path = self._find_output_file(output_dir, video_id, mode)

        size = None
        if final_path and os.path.isfile(final_path):
            size = os.path.getsize(final_path)

        progress.percent = 100.0
        progress.status = "Completed"
        if self.on_progress:
            self.on_progress(progress)

        self._set_state(
            DownloadState.COMPLETED,
            final_path or "Download completed",
        )
        logger.info("Download completed: %s", final_path)

    def cancel(self) -> None:
        """Request cancellation of the running download."""
        self._cancel_requested = True
        proc = self._process
        if proc and proc.poll() is None:
            logger.info("Cancelling download (pid=%s)", proc.pid)
            try:
                if os.name != "nt":
                    # Kill the whole process group
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                else:
                    proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    if os.name != "nt":
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    else:
                        proc.kill()
            except Exception as e:
                logger.warning("Error while cancelling: %s", e)
        self._set_state(DownloadState.CANCELLED, "Download cancelled")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_progress_line(self, line: str) -> Optional[ProgressInfo]:
        """
        Parse yt-dlp progress lines, e.g.:
        [download]  45.2% of  250.00MiB at  4.80MiB/s ETA 00:34
        """
        if "[download]" not in line:
            return None
        # Skip destination / already downloaded messages
        if "Destination:" in line or "has already been downloaded" in line:
            return None

        info = ProgressInfo(status="Downloading")

        # Percent
        m = re.search(r"(\d+\.?\d*)%", line)
        if m:
            info.percent = float(m.group(1))

        # Size: "of  250.00MiB" or "of ~250.00MiB"
        m = re.search(
            r"of\s+~?\s*([\d.]+)\s*([KMGT]?i?B)", line, re.IGNORECASE
        )
        if m:
            info.total_bytes = self._to_bytes(float(m.group(1)), m.group(2))

        # Downloaded size sometimes appears as "123.4MiB of …"
        m = re.search(
            r"(\d+\.?\d*)\s*([KMGT]?i?B)\s+of", line, re.IGNORECASE
        )
        if m:
            info.downloaded_bytes = self._to_bytes(
                float(m.group(1)), m.group(2)
            )
        elif info.total_bytes is not None and info.percent > 0:
            info.downloaded_bytes = info.total_bytes * (info.percent / 100.0)

        # Speed
        m = re.search(
            r"at\s+([\d.]+)\s*([KMGT]?i?B)/s", line, re.IGNORECASE
        )
        if m:
            info.speed = self._to_bytes(float(m.group(1)), m.group(2))

        # ETA
        m = re.search(r"ETA\s+(\d+:\d+(?::\d+)?)", line)
        if m:
            info.eta = self._eta_to_seconds(m.group(1))

        return info

    @staticmethod
    def _to_bytes(value: float, unit: str) -> float:
        unit = unit.upper().replace("I", "")
        multipliers = {
            "B": 1,
            "KB": 1024,
            "MB": 1024**2,
            "GB": 1024**3,
            "TB": 1024**4,
        }
        return value * multipliers.get(unit, 1)

    @staticmethod
    def _eta_to_seconds(eta: str) -> float:
        parts = [int(p) for p in eta.split(":")]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        return float(parts[0]) if parts else 0.0

    def _find_output_file(
        self, output_dir: str, video_id: str, mode: str
    ) -> Optional[str]:
        """Locate the most recently written file matching the video id."""
        ext = "mp3" if mode == "audio" else "mp4"
        candidates = []
        try:
            for name in os.listdir(output_dir):
                if video_id in name and name.endswith(f".{ext}"):
                    path = os.path.join(output_dir, name)
                    candidates.append((os.path.getmtime(path), path))
            if candidates:
                candidates.sort(reverse=True)
                return candidates[0][1]
        except OSError:
            pass
        return None

    def _cleanup_part_files(self, output_dir: str, video_id: str) -> None:
        """Remove incomplete .part files after cancellation."""
        try:
            for name in os.listdir(output_dir):
                if video_id in name and (
                    name.endswith(".part") or name.endswith(".ytdl")
                ):
                    path = os.path.join(output_dir, name)
                    try:
                        os.remove(path)
                        logger.debug("Removed partial file: %s", path)
                    except OSError:
                        pass
        except OSError:
            pass
