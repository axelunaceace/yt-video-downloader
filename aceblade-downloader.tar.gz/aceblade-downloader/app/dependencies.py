"""Dependency checking and installation for AceBlade Downloader."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, List, Optional, Tuple

from .utils import logger, which


class DepStatus(Enum):
    OK = "ok"
    MISSING = "missing"
    CHECKING = "checking"
    INSTALLING = "installing"
    FAILED = "failed"


@dataclass
class Dependency:
    name: str
    status: DepStatus = DepStatus.CHECKING
    version: str = ""
    message: str = ""
    required: bool = True


@dataclass
class CheckResult:
    all_ok: bool
    dependencies: List[Dependency] = field(default_factory=list)
    needs_sudo: bool = False
    missing_names: List[str] = field(default_factory=list)


# Callback types
ProgressCallback = Callable[[str, float], None]  # message, progress 0-1
StatusCallback = Callable[[List[Dependency]], None]


def _run_cmd(
    args: List[str],
    timeout: int = 30,
    env: Optional[dict] = None,
) -> Tuple[int, str, str]:
    """Run a command and return (returncode, stdout, stderr)."""
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except FileNotFoundError:
        return 127, "", "command not found"
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)


def check_python() -> Dependency:
    dep = Dependency(name="Python", status=DepStatus.OK)
    dep.version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info < (3, 8):
        dep.status = DepStatus.FAILED
        dep.message = "Python 3.8+ required"
    else:
        dep.message = f"Python {dep.version}"
    return dep


def check_tkinter() -> Dependency:
    dep = Dependency(name="Tkinter", status=DepStatus.OK)
    try:
        import tkinter
        dep.version = str(tkinter.TkVersion)
        dep.message = f"Tk {dep.version}"
    except ImportError:
        dep.status = DepStatus.MISSING
        dep.message = "Tkinter not available"
    return dep


def check_ytdlp(custom_path: str = "") -> Dependency:
    dep = Dependency(name="yt-dlp", status=DepStatus.CHECKING)
    path = custom_path.strip() if custom_path else which("yt-dlp")
    if not path:
        # Also try common locations
        for candidate in (
            "/usr/bin/yt-dlp",
            "/usr/local/bin/yt-dlp",
            os.path.expanduser("~/.local/bin/yt-dlp"),
        ):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                path = candidate
                break

    if not path:
        dep.status = DepStatus.MISSING
        dep.message = "yt-dlp not found in PATH"
        return dep

    code, out, err = _run_cmd([path, "--version"], timeout=15)
    if code == 0 and out:
        dep.status = DepStatus.OK
        dep.version = out.split("\n")[0].strip()
        dep.message = f"yt-dlp {dep.version}"
        logger.info("Found yt-dlp at %s (%s)", path, dep.version)
    else:
        dep.status = DepStatus.MISSING
        dep.message = err or "yt-dlp not executable"
    return dep


def check_ffmpeg(custom_path: str = "") -> Dependency:
    dep = Dependency(name="FFmpeg", status=DepStatus.CHECKING)
    path = custom_path.strip() if custom_path else which("ffmpeg")
    if not path:
        for candidate in (
            "/usr/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
        ):
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                path = candidate
                break

    if not path:
        dep.status = DepStatus.MISSING
        dep.message = "ffmpeg not found in PATH"
        return dep

    code, out, err = _run_cmd([path, "-version"], timeout=15)
    if code == 0:
        # First line usually: ffmpeg version X.Y.Z ...
        first = (out or err).split("\n")[0]
        version = ""
        if "version" in first.lower():
            parts = first.split()
            for i, p in enumerate(parts):
                if p.lower() == "version" and i + 1 < len(parts):
                    version = parts[i + 1]
                    break
        dep.status = DepStatus.OK
        dep.version = version
        dep.message = f"FFmpeg {version}" if version else "FFmpeg found"
        logger.info("Found FFmpeg at %s (%s)", path, version)
    else:
        dep.status = DepStatus.MISSING
        dep.message = err or "ffmpeg not executable"
    return dep


def check_all(
    ytdlp_path: str = "",
    ffmpeg_path: str = "",
) -> CheckResult:
    """Run full dependency check. Thread-safe."""
    deps = [
        check_python(),
        check_tkinter(),
        check_ytdlp(ytdlp_path),
        check_ffmpeg(ffmpeg_path),
    ]
    missing = [d.name for d in deps if d.status != DepStatus.OK]
    all_ok = len(missing) == 0
    # Installation of yt-dlp / ffmpeg typically needs sudo on Ubuntu
    needs_sudo = any(n in ("yt-dlp", "FFmpeg") for n in missing)
    result = CheckResult(
        all_ok=all_ok,
        dependencies=deps,
        needs_sudo=needs_sudo,
        missing_names=missing,
    )
    logger.info(
        "Dependency check: all_ok=%s missing=%s",
        all_ok,
        missing,
    )
    return result


def get_ytdlp_executable(custom_path: str = "") -> Optional[str]:
    """Return path to yt-dlp executable or None."""
    if custom_path and os.path.isfile(custom_path) and os.access(custom_path, os.X_OK):
        return custom_path
    path = which("yt-dlp")
    if path:
        return path
    for candidate in (
        "/usr/bin/yt-dlp",
        "/usr/local/bin/yt-dlp",
        os.path.expanduser("~/.local/bin/yt-dlp"),
    ):
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def get_ffmpeg_executable(custom_path: str = "") -> Optional[str]:
    """Return path to ffmpeg executable or None."""
    if custom_path and os.path.isfile(custom_path) and os.access(custom_path, os.X_OK):
        return custom_path
    path = which("ffmpeg")
    if path:
        return path
    for candidate in ("/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg"):
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


# ---------------------------------------------------------------------------
# Installation helpers (Ubuntu/Debian)
# ---------------------------------------------------------------------------

def _is_debian_based() -> bool:
    return os.path.isfile("/etc/debian_version") or which("apt-get") is not None


def install_package_apt(
    package: str,
    progress_cb: Optional[ProgressCallback] = None,
    status_cb: Optional[Callable[[str], None]] = None,
) -> Tuple[bool, str]:
    """
    Install a package via apt. Requires sudo.
    Returns (success, message).
    """
    if not _is_debian_based():
        return False, "Automatic installation is only supported on Debian/Ubuntu"

    def _update(msg: str, prog: float = 0.0) -> None:
        if progress_cb:
            progress_cb(msg, prog)
        if status_cb:
            status_cb(msg)
        logger.info(msg)

    _update(f"Updating package lists...", 0.1)
    code, out, err = _run_cmd(
        ["sudo", "-n", "apt-get", "update", "-qq"],
        timeout=120,
    )
    # -n means non-interactive; if password needed it fails quickly
    if code != 0:
        # Need interactive sudo
        _update("Requesting administrator privileges...", 0.15)
        code, out, err = _run_cmd(
            ["sudo", "apt-get", "update", "-qq"],
            timeout=180,
        )
        if code != 0:
            return False, f"apt update failed: {err or out}"

    _update(f"Installing {package}...", 0.4)
    code, out, err = _run_cmd(
        ["sudo", "apt-get", "install", "-y", package],
        timeout=300,
    )
    if code != 0:
        return False, f"Failed to install {package}: {err or out}"

    _update(f"{package} installed successfully", 1.0)
    return True, f"{package} installed"


def install_ytdlp(
    progress_cb: Optional[ProgressCallback] = None,
    status_cb: Optional[Callable[[str], None]] = None,
) -> Tuple[bool, str]:
    """Attempt to install yt-dlp via apt."""
    return install_package_apt("yt-dlp", progress_cb, status_cb)


def install_ffmpeg(
    progress_cb: Optional[ProgressCallback] = None,
    status_cb: Optional[Callable[[str], None]] = None,
) -> Tuple[bool, str]:
    """Attempt to install ffmpeg via apt."""
    return install_package_apt("ffmpeg", progress_cb, status_cb)


def install_missing(
    missing: List[str],
    progress_cb: Optional[ProgressCallback] = None,
    status_cb: Optional[Callable[[str], None]] = None,
    on_dep_update: Optional[StatusCallback] = None,
) -> Tuple[bool, str]:
    """
    Install all missing required packages.
    Returns (all_success, summary_message).
    """
    results = []
    total = len(missing)
    for i, name in enumerate(missing):
        base_prog = i / max(total, 1)
        def scaled_progress(msg: str, p: float) -> None:
            if progress_cb:
                progress_cb(msg, base_prog + p / max(total, 1))

        if name == "yt-dlp":
            ok, msg = install_ytdlp(scaled_progress, status_cb)
        elif name == "FFmpeg":
            ok, msg = install_ffmpeg(scaled_progress, status_cb)
        elif name == "Tkinter":
            ok, msg = install_package_apt(
                "python3-tk", scaled_progress, status_cb
            )
        else:
            ok, msg = False, f"Cannot auto-install {name}"
        results.append((name, ok, msg))
        logger.info("Install %s: %s – %s", name, ok, msg)

    failed = [r for r in results if not r[1]]
    if failed:
        summary = "; ".join(f"{n}: {m}" for n, _, m in failed)
        return False, summary
    return True, "All dependencies installed successfully"


def check_js_runtime() -> Tuple[bool, str]:
    """Check for a supported JS runtime (Deno preferred)."""
    for cmd in ("deno", "node", "nodejs"):
        path = which(cmd)
        if path:
            code, out, _ = _run_cmd([path, "--version"], timeout=10)
            if code == 0:
                return True, f"{cmd} {out.split()[0] if out else ''}".strip()
    return False, ""
