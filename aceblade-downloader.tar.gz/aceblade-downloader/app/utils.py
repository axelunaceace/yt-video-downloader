"""Utility helpers for AceBlade Downloader."""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
from pathlib import Path
from typing import Any, Optional
from urllib.parse import parse_qs, urlparse

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

APP_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = APP_DIR / "data"
LOGS_DIR = APP_DIR / "logs"
ASSETS_DIR = APP_DIR / "assets"
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
LOG_FILE = LOGS_DIR / "aceblade.log"

# Ensure directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
ASSETS_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def setup_logging() -> logging.Logger:
    """Configure application logger."""
    logger = logging.getLogger("aceblade")
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # File handler
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Console handler (warnings+)
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    return logger


logger = setup_logging()


# ---------------------------------------------------------------------------
# URL validation & parsing
# ---------------------------------------------------------------------------

YOUTUBE_PATTERNS = [
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/watch\?v=([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtu\.be/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/shorts/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/embed/([\w-]{11})"),
    re.compile(r"(?:https?://)?(?:www\.)?youtube\.com/v/([\w-]{11})"),
]


def is_valid_youtube_url(url: str) -> bool:
    """Return True if the URL looks like a valid YouTube video URL."""
    if not url or not isinstance(url, str):
        return False
    url = url.strip()
    if not (url.startswith("http://") or url.startswith("https://")):
        return False
    return any(p.search(url) for p in YOUTUBE_PATTERNS)


def extract_video_id(url: str) -> Optional[str]:
    """Extract the 11-character video ID from a YouTube URL."""
    if not url:
        return None
    for pattern in YOUTUBE_PATTERNS:
        match = pattern.search(url)
        if match:
            return match.group(1)
    # Fallback: parse query string
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        if "v" in qs and qs["v"]:
            vid = qs["v"][0]
            if re.match(r"^[\w-]{11}$", vid):
                return vid
    except Exception:
        pass
    return None


def sanitize_filename(name: str, max_length: int = 80) -> str:
    """Create a filesystem-safe filename fragment."""
    if not name:
        return "video"
    # Remove invalid characters
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name)
    # Collapse whitespace
    name = re.sub(r"\s+", " ", name).strip()
    # Truncate
    if len(name) > max_length:
        name = name[:max_length].rstrip()
    return name or "video"


def format_duration(seconds: Optional[float]) -> str:
    """Format seconds into HH:MM:SS or MM:SS."""
    if seconds is None:
        return "--:--"
    try:
        seconds = int(float(seconds))
    except (TypeError, ValueError):
        return "--:--"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def format_bytes(num: Optional[float]) -> str:
    """Human-readable byte size."""
    if num is None:
        return "—"
    try:
        num = float(num)
    except (TypeError, ValueError):
        return "—"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num) < 1024.0:
            return f"{num:.1f} {unit}" if unit != "B" else f"{int(num)} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"


def format_speed(bps: Optional[float]) -> str:
    """Human-readable download speed."""
    if bps is None or bps <= 0:
        return "—"
    return format_bytes(bps) + "/s"


def format_eta(seconds: Optional[float]) -> str:
    """Format ETA seconds into readable string."""
    if seconds is None or seconds < 0:
        return "—"
    try:
        seconds = int(float(seconds))
    except (TypeError, ValueError):
        return "—"
    if seconds < 60:
        return f"00:{seconds:02d}"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m:02d}:{s:02d}"
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def which(cmd: str) -> Optional[str]:
    """Locate an executable in PATH."""
    return shutil.which(cmd)


def load_json(path: Path, default: Any = None) -> Any:
    """Load JSON file safely."""
    if default is None:
        default = {}
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        logger.warning("Failed to load %s: %s", path, e)
    return default


def save_json(path: Path, data: Any) -> bool:
    """Save data as JSON."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        logger.error("Failed to save %s: %s", path, e)
        return False


def open_folder(path: str | Path) -> None:
    """Open a folder in the system file manager."""
    path = str(path)
    try:
        if os.name == "nt":
            os.startfile(path)  # type: ignore
        elif sys_platform() == "darwin":
            import subprocess
            subprocess.Popen(["open", path])
        else:
            import subprocess
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        logger.warning("Could not open folder %s: %s", path, e)


def sys_platform() -> str:
    """Return simplified platform name."""
    import sys
    return sys.platform


def default_download_dir() -> str:
    """Return a sensible default download directory."""
    home = Path.home()
    downloads = home / "Downloads"
    if downloads.is_dir():
        return str(downloads)
    return str(home)
