"""AceBlade Downloader - Modern YouTube downloader for Linux."""

__version__ = "1.0.0"
__app_name__ = "AceBlade Downloader"
