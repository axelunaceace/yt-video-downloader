"""Main GUI for AceBlade Downloader – modern dark Tkinter interface."""

from __future__ import annotations

import os
import threading
import tkinter as tk
from tkinter import filedialog, ttk
from typing import Any, Callable, Dict, List, Optional

from .dependencies import (
    CheckResult,
    DepStatus,
    Dependency,
    check_all,
    check_js_runtime,
    install_missing,
)
from .downloader import DownloadState, Downloader, ProgressInfo, VideoInfo
from .history import History
from .settings import Settings
from .theme import Theme
from .utils import (
    format_bytes,
    is_valid_youtube_url,
    logger,
    open_folder,
    which,
)


# ---------------------------------------------------------------------------
# Custom themed widgets
# ---------------------------------------------------------------------------

class RoundedButton(tk.Canvas):
    """Simple rounded-looking button implemented with Canvas."""

    def __init__(
        self,
        parent,
        text: str = "",
        command: Optional[Callable] = None,
        bg: str = Theme.ACCENT,
        fg: str = Theme.TEXT,
        hover_bg: str = Theme.ACCENT_HOVER,
        width: int = 120,
        height: int = 36,
        font=None,
        **kwargs,
    ):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=parent.cget("bg") if hasattr(parent, "cget") else Theme.BG,
            highlightthickness=0,
            **kwargs,
        )
        self._text = text
        self._command = command
        self._bg = bg
        self._fg = fg
        self._hover_bg = hover_bg
        self._width = width
        self._height = height
        self._font = font or Theme.FONT_BUTTON
        self._enabled = True
        self._draw(bg)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color: str) -> None:
        self.delete("all")
        r = 8
        w, h = self._width, self._height
        # Approximate rounded rect with polygon + ovals
        self.create_rectangle(r, 0, w - r, h, fill=color, outline="")
        self.create_rectangle(0, r, w, h - r, fill=color, outline="")
        self.create_oval(0, 0, 2 * r, 2 * r, fill=color, outline="")
        self.create_oval(w - 2 * r, 0, w, 2 * r, fill=color, outline="")
        self.create_oval(0, h - 2 * r, 2 * r, h, fill=color, outline="")
        self.create_oval(w - 2 * r, h - 2 * r, w, h, fill=color, outline="")
        self.create_text(
            w // 2,
            h // 2,
            text=self._text,
            fill=self._fg,
            font=self._font,
        )

    def _on_enter(self, _=None) -> None:
        if self._enabled:
            self._draw(self._hover_bg)

    def _on_leave(self, _=None) -> None:
        if self._enabled:
            self._draw(self._bg)

    def _on_click(self, _=None) -> None:
        if self._enabled and self._command:
            self._command()

    def set_text(self, text: str) -> None:
        self._text = text
        self._draw(self._bg if self._enabled else Theme.TEXT_DISABLED)

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        color = self._bg if enabled else Theme.CARD_SECONDARY
        self._draw(color)

    def set_colors(self, bg: str, hover: str, fg: str = Theme.TEXT) -> None:
        self._bg = bg
        self._hover_bg = hover
        self._fg = fg
        self._draw(bg)


class ModeCard(tk.Frame):
    """Selectable VIDEO / AUDIO mode card."""

    def __init__(
        self,
        parent,
        title: str,
        subtitle: str,
        icon: str,
        mode: str,
        selected: bool = False,
        on_select: Optional[Callable[[str], None]] = None,
        **kwargs,
    ):
        super().__init__(parent, bg=Theme.CARD, **kwargs)
        self.mode = mode
        self._selected = selected
        self._on_select = on_select
        self._title = title
        self._subtitle = subtitle
        self._icon = icon

        self.configure(highlightbackground=Theme.BORDER, highlightthickness=1)
        self.bind("<Button-1>", self._clicked)
        for child_bind in True,:
            pass

        inner = tk.Frame(self, bg=Theme.CARD, padx=16, pady=14)
        inner.pack(fill="both", expand=True)
        inner.bind("<Button-1>", self._clicked)

        self.icon_lbl = tk.Label(
            inner,
            text=icon,
            font=("Segoe UI", 20),
            bg=Theme.CARD,
            fg=Theme.ACCENT,
        )
        self.icon_lbl.pack(anchor="w")
        self.icon_lbl.bind("<Button-1>", self._clicked)

        self.title_lbl = tk.Label(
            inner,
            text=title,
            font=Theme.FONT_SUBHEADING,
            bg=Theme.CARD,
            fg=Theme.TEXT,
        )
        self.title_lbl.pack(anchor="w", pady=(4, 0))
        self.title_lbl.bind("<Button-1>", self._clicked)

        self.sub_lbl = tk.Label(
            inner,
            text=subtitle,
            font=Theme.FONT_SMALL,
            bg=Theme.CARD,
            fg=Theme.TEXT_SECONDARY,
        )
        self.sub_lbl.pack(anchor="w")
        self.sub_lbl.bind("<Button-1>", self._clicked)

        self._apply_style()

    def _clicked(self, _=None) -> None:
        if self._on_select:
            self._on_select(self.mode)

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        self._apply_style()

    def _apply_style(self) -> None:
        if self._selected:
            self.configure(
                highlightbackground=Theme.ACCENT,
                highlightthickness=2,
                bg=Theme.CARD_SECONDARY,
            )
            for w in (self, self.icon_lbl, self.title_lbl, self.sub_lbl):
                try:
                    w.configure(bg=Theme.CARD_SECONDARY)
                except Exception:
                    pass
            self.icon_lbl.configure(fg=Theme.ACCENT)
        else:
            self.configure(
                highlightbackground=Theme.BORDER,
                highlightthickness=1,
                bg=Theme.CARD,
            )
            for w in (self, self.icon_lbl, self.title_lbl, self.sub_lbl):
                try:
                    w.configure(bg=Theme.CARD)
                except Exception:
                    pass
            self.icon_lbl.configure(fg=Theme.TEXT_SECONDARY)


class ProgressBar(tk.Canvas):
    """Custom progress bar."""

    def __init__(self, parent, width: int = 400, height: int = 8, **kwargs):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=Theme.PROGRESS_BG,
            highlightthickness=0,
            **kwargs,
        )
        self._width = width
        self._height = height
        self._value = 0.0
        self._draw()

    def set(self, value: float) -> None:
        self._value = max(0.0, min(100.0, value))
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        self.create_rectangle(
            0, 0, self._width, self._height, fill=Theme.PROGRESS_BG, outline=""
        )
        fill_w = int(self._width * (self._value / 100.0))
        if fill_w > 0:
            self.create_rectangle(
                0, 0, fill_w, self._height, fill=Theme.PROGRESS_FILL, outline=""
            )


# ---------------------------------------------------------------------------
# Dialogs
# ---------------------------------------------------------------------------

class BaseDialog(tk.Toplevel):
    """Base for custom dialogs."""

    def __init__(self, parent, title: str = "", width: int = 400, height: int = 280):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=Theme.BG)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        # Center
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - width) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")

        self.bind("<Escape>", lambda e: self.destroy())


class SuccessDialog(BaseDialog):
    def __init__(
        self,
        parent,
        filename: str = "",
        folder: str = "",
    ):
        super().__init__(parent, "Download Complete", 420, 300)
        self.folder = folder

        tk.Label(
            self,
            text="✓",
            font=("Segoe UI", 36),
            bg=Theme.BG,
            fg=Theme.SUCCESS,
        ).pack(pady=(24, 4))

        tk.Label(
            self,
            text="Download Complete!",
            font=Theme.FONT_HEADING,
            bg=Theme.BG,
            fg=Theme.TEXT,
        ).pack()

        tk.Label(
            self,
            text="Your file was downloaded successfully.",
            font=Theme.FONT_BODY,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(pady=(4, 12))

        if filename:
            tk.Label(
                self,
                text=os.path.basename(filename),
                font=Theme.FONT_SMALL,
                bg=Theme.BG,
                fg=Theme.ACCENT,
                wraplength=360,
            ).pack(pady=(0, 16))

        btn_frame = tk.Frame(self, bg=Theme.BG)
        btn_frame.pack(pady=8)

        RoundedButton(
            btn_frame,
            text="Open Folder",
            command=self._open,
            bg=Theme.ACCENT,
            hover_bg=Theme.ACCENT_HOVER,
            width=130,
            height=36,
        ).pack(side="left", padx=6)

        RoundedButton(
            btn_frame,
            text="Close",
            command=self.destroy,
            bg=Theme.CARD_SECONDARY,
            hover_bg=Theme.CARD_HOVER,
            width=100,
            height=36,
        ).pack(side="left", padx=6)

    def _open(self) -> None:
        if self.folder:
            open_folder(self.folder)
        self.destroy()


class ErrorDialog(BaseDialog):
    def __init__(
        self,
        parent,
        title: str = "Error",
        message: str = "",
        details: str = "",
    ):
        height = 320 if details else 260
        super().__init__(parent, title, 440, height)

        tk.Label(
            self,
            text="⚠",
            font=("Segoe UI", 32),
            bg=Theme.BG,
            fg=Theme.ERROR,
        ).pack(pady=(20, 4))

        tk.Label(
            self,
            text=title,
            font=Theme.FONT_HEADING,
            bg=Theme.BG,
            fg=Theme.TEXT,
        ).pack()

        tk.Label(
            self,
            text=message,
            font=Theme.FONT_BODY,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
            wraplength=380,
            justify="center",
        ).pack(pady=(8, 8))

        self._details = details
        self._details_visible = False
        self._details_frame = None

        if details:
            self._toggle_btn = RoundedButton(
                self,
                text="Show Details",
                command=self._toggle_details,
                bg=Theme.CARD_SECONDARY,
                hover_bg=Theme.CARD_HOVER,
                width=130,
                height=30,
                font=Theme.FONT_SMALL,
            )
            self._toggle_btn.pack(pady=4)

        RoundedButton(
            self,
            text="Close",
            command=self.destroy,
            bg=Theme.ACCENT,
            hover_bg=Theme.ACCENT_HOVER,
            width=100,
            height=36,
        ).pack(pady=(12, 0))

    def _toggle_details(self) -> None:
        if self._details_visible:
            if self._details_frame:
                self._details_frame.destroy()
                self._details_frame = None
            self._toggle_btn.set_text("Show Details")
            self._details_visible = False
        else:
            self._details_frame = tk.Frame(self, bg=Theme.CARD)
            self._details_frame.pack(fill="x", padx=20, pady=8)
            txt = tk.Text(
                self._details_frame,
                height=4,
                bg=Theme.INPUT_BG,
                fg=Theme.TEXT_SECONDARY,
                font=Theme.FONT_MONO_SMALL,
                wrap="word",
                relief="flat",
                highlightthickness=0,
            )
            txt.pack(fill="x", padx=4, pady=4)
            txt.insert("1.0", self._details)
            txt.configure(state="disabled")
            self._toggle_btn.set_text("Hide Details")
            self._details_visible = True


# ---------------------------------------------------------------------------
# Setup / Dependency window
# ---------------------------------------------------------------------------

class SetupWindow(tk.Toplevel):
    """Beautiful first-launch dependency setup window."""

    def __init__(self, parent, on_complete: Callable[[], None]):
        super().__init__(parent)
        self.on_complete = on_complete
        self.title("AceBlade – Setup")
        self.configure(bg=Theme.BG)
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        w, h = Theme.SETUP_WIDTH, Theme.SETUP_HEIGHT
        self.geometry(f"{w}x{h}")
        self.update_idletasks()
        x = (self.winfo_screenwidth() - w) // 2
        y = (self.winfo_screenheight() - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

        self._deps: List[Dependency] = []
        self._installing = False
        self._build_ui()
        self.after(200, self._start_check)

    def _build_ui(self) -> None:
        # Logo / title
        tk.Label(
            self,
            text="⚡ ACEBLADE",
            font=("Segoe UI", 24, "bold"),
            bg=Theme.BG,
            fg=Theme.ACCENT,
        ).pack(pady=(28, 0))
        tk.Label(
            self,
            text="DOWNLOADER",
            font=("Segoe UI", 14, "bold"),
            bg=Theme.BG,
            fg=Theme.TEXT,
        ).pack()

        tk.Label(
            self,
            text="Preparing your environment",
            font=Theme.FONT_BODY,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(pady=(16, 12))

        # Card with dependency list
        card = tk.Frame(self, bg=Theme.CARD, padx=20, pady=14)
        card.pack(fill="x", padx=40)
        self.dep_frame = tk.Frame(card, bg=Theme.CARD)
        self.dep_frame.pack(fill="x")

        self.status_lbl = tk.Label(
            self,
            text="Checking dependencies…",
            font=Theme.FONT_BODY,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        )
        self.status_lbl.pack(pady=(16, 6))

        self.progress = ProgressBar(self, width=360, height=10)
        self.progress.pack(pady=4)

        self.hint_lbl = tk.Label(
            self,
            text="Please wait…",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_MUTED,
        )
        self.hint_lbl.pack(pady=(8, 0))

    def _render_deps(self) -> None:
        for w in self.dep_frame.winfo_children():
            w.destroy()
        icons = {
            DepStatus.OK: "✓",
            DepStatus.MISSING: "○",
            DepStatus.CHECKING: "⟳",
            DepStatus.INSTALLING: "⟳",
            DepStatus.FAILED: "✗",
        }
        colors = {
            DepStatus.OK: Theme.SUCCESS,
            DepStatus.MISSING: Theme.TEXT_MUTED,
            DepStatus.CHECKING: Theme.ACCENT,
            DepStatus.INSTALLING: Theme.ACCENT,
            DepStatus.FAILED: Theme.ERROR,
        }
        for dep in self._deps:
            row = tk.Frame(self.dep_frame, bg=Theme.CARD)
            row.pack(fill="x", pady=3)
            icon = icons.get(dep.status, "○")
            color = colors.get(dep.status, Theme.TEXT_MUTED)
            tk.Label(
                row,
                text=f"  {icon}  {dep.name}",
                font=Theme.FONT_BODY,
                bg=Theme.CARD,
                fg=color,
                anchor="w",
            ).pack(side="left")
            if dep.version:
                tk.Label(
                    row,
                    text=dep.version,
                    font=Theme.FONT_TINY,
                    bg=Theme.CARD,
                    fg=Theme.TEXT_MUTED,
                ).pack(side="right")

    def _start_check(self) -> None:
        def worker() -> None:
            result = check_all()
            self.after(0, lambda: self._on_check_done(result))

        threading.Thread(target=worker, daemon=True).start()

    def _on_check_done(self, result: CheckResult) -> None:
        self._deps = result.dependencies
        self._render_deps()
        if result.all_ok:
            self.status_lbl.configure(text="All dependencies ready", fg=Theme.SUCCESS)
            self.progress.set(100)
            self.hint_lbl.configure(text="Launching…")
            self.after(800, self._finish)
        else:
            missing = result.missing_names
            self.status_lbl.configure(
                text=f"Installing missing: {', '.join(missing)}",
                fg=Theme.WARNING,
            )
            self.hint_lbl.configure(
                text="Administrator privileges may be required"
            )
            self.after(400, lambda: self._start_install(missing))

    def _start_install(self, missing: List[str]) -> None:
        self._installing = True

        def progress_cb(msg: str, prog: float) -> None:
            self.after(0, lambda: self._update_progress(msg, prog))

        def status_cb(msg: str) -> None:
            self.after(0, lambda: self.status_lbl.configure(text=msg))

        def worker() -> None:
            ok, summary = install_missing(missing, progress_cb, status_cb)
            self.after(0, lambda: self._on_install_done(ok, summary))

        threading.Thread(target=worker, daemon=True).start()

    def _update_progress(self, msg: str, prog: float) -> None:
        self.status_lbl.configure(text=msg)
        self.progress.set(prog * 100)

    def _on_install_done(self, ok: bool, summary: str) -> None:
        self._installing = False
        if ok:
            # Re-check
            result = check_all()
            self._deps = result.dependencies
            self._render_deps()
            if result.all_ok:
                self.status_lbl.configure(
                    text="Setup complete!", fg=Theme.SUCCESS
                )
                self.progress.set(100)
                self.hint_lbl.configure(text="Launching…")
                self.after(900, self._finish)
            else:
                self.status_lbl.configure(
                    text="Some dependencies still missing", fg=Theme.ERROR
                )
                self.hint_lbl.configure(text=summary[:80])
                self._show_manual_hint(result.missing_names)
        else:
            self.status_lbl.configure(text="Installation failed", fg=Theme.ERROR)
            self.hint_lbl.configure(text=summary[:100])
            self._show_manual_hint([])

    def _show_manual_hint(self, missing: List[str]) -> None:
        tip = (
            "Please install manually:\n"
            "  sudo apt update && sudo apt install -y yt-dlp ffmpeg python3-tk"
        )
        tk.Label(
            self,
            text=tip,
            font=Theme.FONT_TINY,
            bg=Theme.BG,
            fg=Theme.TEXT_MUTED,
            justify="left",
        ).pack(pady=8)
        RoundedButton(
            self,
            text="Continue Anyway",
            command=self._finish,
            bg=Theme.CARD_SECONDARY,
            hover_bg=Theme.CARD_HOVER,
            width=150,
            height=32,
        ).pack(pady=4)

    def _finish(self) -> None:
        self.destroy()
        self.on_complete()

    def _on_close(self) -> None:
        if self._installing:
            return  # prevent closing during install
        self.destroy()
        # Still try to continue – user may have deps
        self.on_complete()


# ---------------------------------------------------------------------------
# Settings dialog
# ---------------------------------------------------------------------------

class SettingsDialog(BaseDialog):
    def __init__(self, parent, settings: Settings, on_save: Callable[[], None]):
        super().__init__(parent, "Settings", 480, 520)
        self.settings = settings
        self.on_save = on_save
        self._build()

    def _build(self) -> None:
        canvas = tk.Canvas(self, bg=Theme.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=Theme.BG)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=(16, 0), pady=12)
        scrollbar.pack(side="right", fill="y", pady=12, padx=(0, 8))

        # --- General ---
        self._section(scroll_frame, "General")
        self.folder_var = tk.StringVar(value=self.settings.download_folder)
        self._labeled_entry(scroll_frame, "Download folder", self.folder_var)
        browse = RoundedButton(
            scroll_frame,
            text="Browse…",
            command=self._browse_folder,
            bg=Theme.CARD_SECONDARY,
            hover_bg=Theme.CARD_HOVER,
            width=100,
            height=28,
            font=Theme.FONT_SMALL,
        )
        browse.pack(anchor="e", padx=8, pady=2)

        self.mode_var = tk.StringVar(value=self.settings.last_mode)
        self._labeled_option(
            scroll_frame,
            "Default mode",
            self.mode_var,
            ["video", "audio"],
        )

        # --- Audio ---
        self._section(scroll_frame, "Audio")
        self.audio_q_var = tk.StringVar(value=self.settings.audio_quality)
        self._labeled_option(
            scroll_frame,
            "MP3 quality (kbps)",
            self.audio_q_var,
            ["128", "192", "256", "320"],
        )

        # --- Advanced ---
        self._section(scroll_frame, "Advanced")
        self.ytdlp_var = tk.StringVar(value=self.settings.ytdlp_path)
        self._labeled_entry(scroll_frame, "yt-dlp path (empty = auto)", self.ytdlp_var)
        self.ffmpeg_var = tk.StringVar(value=self.settings.ffmpeg_path)
        self._labeled_entry(scroll_frame, "FFmpeg path (empty = auto)", self.ffmpeg_var)
        self.maxlen_var = tk.StringVar(
            value=str(self.settings.max_filename_length)
        )
        self._labeled_entry(scroll_frame, "Max filename length", self.maxlen_var)

        # Save button
        btn_frame = tk.Frame(self, bg=Theme.BG)
        btn_frame.pack(side="bottom", fill="x", pady=12)
        RoundedButton(
            btn_frame,
            text="Save",
            command=self._save,
            bg=Theme.ACCENT,
            hover_bg=Theme.ACCENT_HOVER,
            width=120,
            height=36,
        ).pack()

    def _section(self, parent, title: str) -> None:
        tk.Label(
            parent,
            text=title,
            font=Theme.FONT_SUBHEADING,
            bg=Theme.BG,
            fg=Theme.ACCENT,
        ).pack(anchor="w", padx=8, pady=(14, 4))

    def _labeled_entry(self, parent, label: str, var: tk.StringVar) -> None:
        tk.Label(
            parent,
            text=label,
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w", padx=8)
        entry = tk.Entry(
            parent,
            textvariable=var,
            bg=Theme.INPUT_BG,
            fg=Theme.TEXT,
            insertbackground=Theme.TEXT,
            relief="flat",
            font=Theme.FONT_BODY,
            highlightthickness=1,
            highlightbackground=Theme.BORDER,
            highlightcolor=Theme.BORDER_FOCUS,
        )
        entry.pack(fill="x", padx=8, pady=(2, 6), ipady=4)

    def _labeled_option(
        self, parent, label: str, var: tk.StringVar, values: List[str]
    ) -> None:
        tk.Label(
            parent,
            text=label,
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w", padx=8)
        om = ttk.OptionMenu(parent, var, var.get(), *values)
        om.pack(anchor="w", padx=8, pady=(2, 6))

    def _browse_folder(self) -> None:
        path = filedialog.askdirectory(
            initialdir=self.folder_var.get() or os.path.expanduser("~")
        )
        if path:
            self.folder_var.set(path)

    def _save(self) -> None:
        self.settings.download_folder = self.folder_var.get().strip()
        self.settings.last_mode = self.mode_var.get()
        self.settings.audio_quality = self.audio_q_var.get()
        self.settings.set("advanced", "ytdlp_path", self.ytdlp_var.get().strip())
        self.settings.set("advanced", "ffmpeg_path", self.ffmpeg_var.get().strip())
        try:
            self.settings.set(
                "advanced",
                "max_filename_length",
                int(self.maxlen_var.get()),
            )
        except ValueError:
            pass
        self.settings.save()
        self.on_save()
        self.destroy()


# ---------------------------------------------------------------------------
# Main Application Window
# ---------------------------------------------------------------------------

class MainApp(tk.Tk):
    """AceBlade Downloader main window."""

    def __init__(self) -> None:
        super().__init__()
        self.title("⚡ AceBlade Downloader")
        self.configure(bg=Theme.BG)
        self.minsize(Theme.MIN_WIDTH, Theme.MIN_HEIGHT)
        self.geometry(f"{Theme.MAIN_WIDTH}x{Theme.MAIN_HEIGHT}")

        # Center
        self.update_idletasks()
        x = (self.winfo_screenwidth() - Theme.MAIN_WIDTH) // 2
        y = (self.winfo_screenheight() - Theme.MAIN_HEIGHT) // 2
        self.geometry(f"+{x}+{y}")

        self.settings = Settings()
        self.history = History()
        self.downloader = Downloader(
            ytdlp_path=self.settings.ytdlp_path,
            ffmpeg_path=self.settings.ffmpeg_path,
            max_filename_length=self.settings.max_filename_length,
        )
        self.downloader.on_progress = self._on_progress
        self.downloader.on_state = self._on_state
        self.downloader.on_info = self._on_info

        self._mode = self.settings.last_mode
        self._video_info: Optional[VideoInfo] = None
        self._current_filepath: str = ""

        self._build_ui()
        self._bind_shortcuts()
        self._refresh_history()

        # JS runtime check (non-blocking)
        self.after(1500, self._check_js_runtime)

        logger.info("Main window ready")

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        # Header
        header = tk.Frame(self, bg=Theme.BG)
        header.pack(fill="x", padx=24, pady=(16, 4))

        tk.Label(
            header,
            text="⚡ AceBlade Downloader",
            font=Theme.FONT_TITLE,
            bg=Theme.BG,
            fg=Theme.TEXT,
        ).pack(side="left")

        RoundedButton(
            header,
            text="⚙ Settings",
            command=self._open_settings,
            bg=Theme.CARD,
            hover_bg=Theme.CARD_HOVER,
            width=110,
            height=32,
            font=Theme.FONT_SMALL,
        ).pack(side="right")

        # Tagline
        tk.Label(
            self,
            text="Download anything you need  ·  Fast · Simple · Reliable",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w", padx=24, pady=(0, 12))

        # URL section
        url_frame = tk.Frame(self, bg=Theme.BG)
        url_frame.pack(fill="x", padx=24, pady=4)

        tk.Label(
            url_frame,
            text="YouTube URL",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w")

        entry_row = tk.Frame(url_frame, bg=Theme.BG)
        entry_row.pack(fill="x", pady=(4, 0))

        self.url_var = tk.StringVar()
        self.url_entry = tk.Entry(
            entry_row,
            textvariable=self.url_var,
            bg=Theme.INPUT_BG,
            fg=Theme.TEXT,
            insertbackground=Theme.TEXT,
            relief="flat",
            font=Theme.FONT_BODY,
            highlightthickness=1,
            highlightbackground=Theme.BORDER,
            highlightcolor=Theme.BORDER_FOCUS,
        )
        self.url_entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 8))
        self.url_entry.insert(0, "")
        self._placeholder = "🔗  Paste your YouTube URL…"
        self._show_placeholder()
        self.url_entry.bind("<FocusIn>", self._clear_placeholder)
        self.url_entry.bind("<FocusOut>", self._show_placeholder)

        RoundedButton(
            entry_row,
            text="Paste",
            command=self._paste_url,
            bg=Theme.CARD_SECONDARY,
            hover_bg=Theme.CARD_HOVER,
            width=80,
            height=36,
        ).pack(side="left", padx=(0, 6))

        RoundedButton(
            entry_row,
            text="Fetch Info",
            command=self._fetch_info,
            bg=Theme.ACCENT,
            hover_bg=Theme.ACCENT_HOVER,
            width=100,
            height=36,
        ).pack(side="left")

        # Mode cards
        mode_frame = tk.Frame(self, bg=Theme.BG)
        mode_frame.pack(fill="x", padx=24, pady=16)

        self.video_card = ModeCard(
            mode_frame,
            title="VIDEO",
            subtitle="MP4  ·  Best quality",
            icon="🎬",
            mode="video",
            selected=self._mode == "video",
            on_select=self._select_mode,
        )
        self.video_card.pack(side="left", fill="both", expand=True, padx=(0, 8))

        self.audio_card = ModeCard(
            mode_frame,
            title="AUDIO",
            subtitle="MP3  ·  192 kbps",
            icon="🎵",
            mode="audio",
            selected=self._mode == "audio",
            on_select=self._select_mode,
        )
        self.audio_card.pack(side="left", fill="both", expand=True, padx=(8, 0))

        # Download location
        loc_frame = tk.Frame(self, bg=Theme.BG)
        loc_frame.pack(fill="x", padx=24, pady=4)

        tk.Label(
            loc_frame,
            text="Download location",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w")

        loc_row = tk.Frame(loc_frame, bg=Theme.BG)
        loc_row.pack(fill="x", pady=(4, 0))

        self.folder_var = tk.StringVar(value=self.settings.download_folder)
        self.folder_entry = tk.Entry(
            loc_row,
            textvariable=self.folder_var,
            bg=Theme.INPUT_BG,
            fg=Theme.TEXT,
            insertbackground=Theme.TEXT,
            relief="flat",
            font=Theme.FONT_BODY,
            highlightthickness=1,
            highlightbackground=Theme.BORDER,
            highlightcolor=Theme.BORDER_FOCUS,
        )
        self.folder_entry.pack(
            side="left", fill="x", expand=True, ipady=6, padx=(0, 8)
        )

        RoundedButton(
            loc_row,
            text="Browse",
            command=self._browse_folder,
            bg=Theme.CARD_SECONDARY,
            hover_bg=Theme.CARD_HOVER,
            width=90,
            height=34,
        ).pack(side="left")

        # Video info preview card (hidden initially)
        self.info_card = tk.Frame(self, bg=Theme.CARD, padx=12, pady=10)
        # packed later when info is available

        self.thumb_label = tk.Label(
            self.info_card, text="🎬", font=("Segoe UI", 28), bg=Theme.CARD, fg=Theme.ACCENT
        )
        self.thumb_label.pack(side="left", padx=(4, 12))

        info_text = tk.Frame(self.info_card, bg=Theme.CARD)
        info_text.pack(side="left", fill="both", expand=True)

        self.info_title = tk.Label(
            info_text,
            text="",
            font=Theme.FONT_SUBHEADING,
            bg=Theme.CARD,
            fg=Theme.TEXT,
            anchor="w",
            wraplength=500,
            justify="left",
        )
        self.info_title.pack(anchor="w")

        self.info_meta = tk.Label(
            info_text,
            text="",
            font=Theme.FONT_SMALL,
            bg=Theme.CARD,
            fg=Theme.TEXT_SECONDARY,
            anchor="w",
        )
        self.info_meta.pack(anchor="w", pady=(4, 0))

        # Download button
        self.download_btn = RoundedButton(
            self,
            text="↓  DOWNLOAD",
            command=self._start_download,
            bg=Theme.ACCENT,
            hover_bg=Theme.ACCENT_HOVER,
            width=280,
            height=48,
            font=("Segoe UI", 13, "bold"),
        )
        self.download_btn.pack(pady=16)

        self.cancel_btn = RoundedButton(
            self,
            text="Cancel",
            command=self._cancel_download,
            bg=Theme.ERROR,
            hover_bg="#DC2626",
            width=120,
            height=36,
        )
        # not packed until downloading

        # Progress section
        prog_frame = tk.Frame(self, bg=Theme.BG)
        prog_frame.pack(fill="x", padx=24, pady=4)

        tk.Label(
            prog_frame,
            text="Download Progress",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_SECONDARY,
        ).pack(anchor="w")

        self.progress_bar = ProgressBar(prog_frame, width=860, height=10)
        self.progress_bar.pack(fill="x", pady=(6, 4))

        self.progress_lbl = tk.Label(
            prog_frame,
            text="Ready",
            font=Theme.FONT_SMALL,
            bg=Theme.BG,
            fg=Theme.TEXT_MUTED,
            anchor="w",
        )
        self.progress_lbl.pack(fill="x")

        # History section
        hist_header = tk.Frame(self, bg=Theme.BG)
        hist_header.pack(fill="x", padx=24, pady=(16, 4))
        tk.Label(
            hist_header,
            text="Recent Downloads",
            font=Theme.FONT_SUBHEADING,
            bg=Theme.BG,
            fg=Theme.TEXT,
        ).pack(side="left")

        self.history_frame = tk.Frame(self, bg=Theme.BG)
        self.history_frame.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        # Status bar
        self.status_bar = tk.Label(
            self,
            text="Ready",
            font=Theme.FONT_TINY,
            bg=Theme.CARD,
            fg=Theme.TEXT_MUTED,
            anchor="w",
            padx=12,
            pady=4,
        )
        self.status_bar.pack(side="bottom", fill="x")

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-v>", lambda e: self._paste_url())
        self.bind("<Control-V>", lambda e: self._paste_url())
        self.bind("<Return>", lambda e: self._fetch_info())
        self.bind("<Control-Return>", lambda e: self._start_download())
        self.bind("<Escape>", lambda e: self._cancel_download())

    # ------------------------------------------------------------------
    # Placeholder helpers
    # ------------------------------------------------------------------

    def _show_placeholder(self, _=None) -> None:
        if not self.url_var.get():
            self.url_entry.configure(fg=Theme.TEXT_MUTED)
            self.url_var.set(self._placeholder)

    def _clear_placeholder(self, _=None) -> None:
        if self.url_var.get() == self._placeholder:
            self.url_var.set("")
            self.url_entry.configure(fg=Theme.TEXT)

    def _get_url(self) -> str:
        url = self.url_var.get().strip()
        if url == self._placeholder:
            return ""
        return url

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def _paste_url(self) -> None:
        try:
            clip = self.clipboard_get()
            if clip:
                self._clear_placeholder()
                self.url_var.set(clip.strip())
                self.url_entry.configure(fg=Theme.TEXT)
        except tk.TclError:
            pass

    def _select_mode(self, mode: str) -> None:
        self._mode = mode
        self.video_card.set_selected(mode == "video")
        self.audio_card.set_selected(mode == "audio")
        # Update audio card subtitle with quality
        q = self.settings.audio_quality
        self.audio_card.sub_lbl.configure(text=f"MP3  ·  {q} kbps")

    def _browse_folder(self) -> None:
        path = filedialog.askdirectory(
            initialdir=self.folder_var.get() or os.path.expanduser("~")
        )
        if path:
            self.folder_var.set(path)
            self.settings.download_folder = path
            self.settings.save()

    def _fetch_info(self) -> None:
        url = self._get_url()
        if not url:
            self._set_status("Please paste a YouTube URL first", error=True)
            return
        if not is_valid_youtube_url(url):
            self._set_status("Invalid YouTube URL", error=True)
            return
        self._set_status("Fetching video information…")
        self.downloader.fetch_info(url)

    def _start_download(self) -> None:
        url = self._get_url()
        if not url:
            self._set_status("Please paste a YouTube URL first", error=True)
            return
        if not is_valid_youtube_url(url):
            self._set_status("Invalid YouTube URL", error=True)
            return

        folder = self.folder_var.get().strip() or self.settings.download_folder
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder, exist_ok=True)
            except OSError as e:
                self._set_status(f"Cannot create folder: {e}", error=True)
                return

        self.settings.last_mode = self._mode
        self.settings.download_folder = folder
        self.settings.save()

        self.download_btn.pack_forget()
        self.cancel_btn.pack(pady=12)
        self.progress_bar.set(0)
        self.progress_lbl.configure(text="Starting…")

        self.downloader.download(
            url=url,
            output_dir=folder,
            mode=self._mode,
            audio_quality=self.settings.audio_quality,
            video_info=self._video_info,
        )

    def _cancel_download(self) -> None:
        if self.downloader.state in (
            DownloadState.DOWNLOADING,
            DownloadState.POSTPROCESSING,
        ):
            self.downloader.cancel()
            self._set_status("Cancelling…")

    def _open_settings(self) -> None:
        SettingsDialog(self, self.settings, on_save=self._on_settings_saved)

    def _on_settings_saved(self) -> None:
        self.folder_var.set(self.settings.download_folder)
        self.downloader.ytdlp_path = self.settings.ytdlp_path
        self.downloader.ffmpeg_path = self.settings.ffmpeg_path
        self.downloader.max_filename_length = self.settings.max_filename_length
        self._select_mode(self.settings.last_mode)
        self._set_status("Settings saved")

    # ------------------------------------------------------------------
    # Downloader callbacks (marshalled to main thread)
    # ------------------------------------------------------------------

    def _on_progress(self, info: ProgressInfo) -> None:
        self.after(0, lambda: self._apply_progress(info))

    def _apply_progress(self, info: ProgressInfo) -> None:
        self.progress_bar.set(info.percent)
        parts = [
            info.percent_str,
            info.speed_str,
            info.size_str,
            f"{info.eta_str} left" if info.eta is not None else "",
        ]
        text = "    ".join(p for p in parts if p and p != "—")
        self.progress_lbl.configure(text=text or info.status)
        self._set_status(info.status or "Downloading…")

    def _on_state(self, state: DownloadState, message: str) -> None:
        self.after(0, lambda: self._apply_state(state, message))

    def _apply_state(self, state: DownloadState, message: str) -> None:
        if state == DownloadState.COMPLETED:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_bar.set(100)
            self.progress_lbl.configure(text="Completed")
            filepath = message if message and os.path.isfile(message) else ""
            self._current_filepath = filepath
            folder = self.folder_var.get()
            title = (
                self._video_info.title
                if self._video_info
                else os.path.basename(filepath) if filepath else "Download"
            )
            size = None
            if filepath and os.path.isfile(filepath):
                size = os.path.getsize(filepath)
            self.history.add(
                title=title,
                mode=self._mode,
                filepath=filepath or folder,
                size_bytes=size,
                video_id=self._video_info.id if self._video_info else "",
            )
            self._refresh_history()
            SuccessDialog(self, filename=filepath, folder=folder)
            self._set_status("Download complete")

        elif state == DownloadState.CANCELLED:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_lbl.configure(text="Cancelled")
            self._set_status("Download cancelled")

        elif state == DownloadState.ERROR:
            self.cancel_btn.pack_forget()
            self.download_btn.pack(pady=16)
            self.progress_lbl.configure(text="Failed")
            self._set_status(message or "Download failed", error=True)
            ErrorDialog(
                self,
                title="Download Failed",
                message="Something went wrong while downloading.",
                details=message,
            )

        elif state == DownloadState.DOWNLOADING:
            self._set_status("Downloading…")

        elif state == DownloadState.POSTPROCESSING:
            self._set_status("Post-processing (FFmpeg)…")
            self.progress_lbl.configure(text="Merging / converting…")

        elif state == DownloadState.FETCHING_INFO:
            self._set_status("Fetching video info…")

    def _on_info(self, info: Optional[VideoInfo], error: Optional[str]) -> None:
        self.after(0, lambda: self._apply_info(info, error))

    def _apply_info(self, info: Optional[VideoInfo], error: Optional[str]) -> None:
        if error:
            self._set_status(error, error=True)
            self.info_card.pack_forget()
            self._video_info = None
            return

        if not info:
            return

        self._video_info = info
        self.info_title.configure(text=info.title or "Unknown title")
        meta_parts = []
        if info.uploader:
            meta_parts.append(info.uploader)
        if info.duration is not None:
            meta_parts.append(f"⏱ {info.duration_str}")
        if info.id:
            meta_parts.append(f"ID: {info.id}")
        self.info_meta.configure(text="  ·  ".join(meta_parts))
        # Show the preview card (re-pack to ensure correct order)
        self.info_card.pack_forget()
        self.info_card.pack(fill="x", padx=24, pady=8)
        self._set_status(f"Ready: {info.title[:60]}")

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    def _refresh_history(self) -> None:
        for w in self.history_frame.winfo_children():
            w.destroy()

        entries = self.history.get_recent(8)
        if not entries:
            tk.Label(
                self.history_frame,
                text="No downloads yet",
                font=Theme.FONT_SMALL,
                bg=Theme.BG,
                fg=Theme.TEXT_MUTED,
            ).pack(anchor="w")
            return

        for entry in entries:
            row = tk.Frame(self.history_frame, bg=Theme.CARD, padx=10, pady=6)
            row.pack(fill="x", pady=2)

            icon = "🎬" if entry.get("mode") == "video" else "🎵"
            tk.Label(
                row,
                text=icon,
                font=("Segoe UI", 14),
                bg=Theme.CARD,
                fg=Theme.ACCENT,
            ).pack(side="left", padx=(0, 8))

            text_frame = tk.Frame(row, bg=Theme.CARD)
            text_frame.pack(side="left", fill="x", expand=True)

            title = entry.get("title", "Unknown")[:55]
            tk.Label(
                text_frame,
                text=title,
                font=Theme.FONT_SMALL,
                bg=Theme.CARD,
                fg=Theme.TEXT,
                anchor="w",
            ).pack(anchor="w")

            rel = History.relative_date(entry.get("timestamp", 0))
            size = format_bytes(entry.get("size_bytes"))
            tk.Label(
                text_frame,
                text=f"{rel}  ·  {size}",
                font=Theme.FONT_TINY,
                bg=Theme.CARD,
                fg=Theme.TEXT_MUTED,
                anchor="w",
            ).pack(anchor="w")

            path = entry.get("filepath", "")
            if path and os.path.exists(path):
                RoundedButton(
                    row,
                    text="Open",
                    command=lambda p=path: open_folder(
                        os.path.dirname(p) if os.path.isfile(p) else p
                    ),
                    bg=Theme.CARD_SECONDARY,
                    hover_bg=Theme.CARD_HOVER,
                    width=60,
                    height=26,
                    font=Theme.FONT_TINY,
                ).pack(side="right")

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _set_status(self, text: str, error: bool = False) -> None:
        self.status_bar.configure(
            text=text,
            fg=Theme.ERROR if error else Theme.TEXT_MUTED,
        )

    def _check_js_runtime(self) -> None:
        ok, version = check_js_runtime()
        if not ok:
            self._set_status(
                "⚠ Advanced YouTube extraction support unavailable (install Deno for best results)"
            )
            logger.info("No JS runtime detected")
        else:
            logger.info("JS runtime: %s", version)


# ---------------------------------------------------------------------------
# Application entry helpers
# ---------------------------------------------------------------------------

def run_setup_then_main() -> None:
    """Show setup window if needed, then main app."""
    # Minimal root for dialogs
    root = tk.Tk()
    root.withdraw()

    def launch_main() -> None:
        root.destroy()
        app = MainApp()
        app.mainloop()

    # Quick check first
    result = check_all()
    if result.all_ok:
        launch_main()
    else:
        # Show setup
        setup = SetupWindow(root, on_complete=launch_main)
        root.wait_window(setup)
        # If setup was closed without completing, still try
        if not root.winfo_exists():
            return
        try:
            launch_main()
        except Exception:
            pass


def run_main_directly() -> None:
    """Skip setup, open main window immediately."""
    app = MainApp()
    app.mainloop()
