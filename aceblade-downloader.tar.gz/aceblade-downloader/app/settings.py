"""Settings management for AceBlade Downloader."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .utils import SETTINGS_FILE, default_download_dir, load_json, save_json, logger


DEFAULT_SETTINGS: Dict[str, Any] = {
    "general": {
        "download_folder": default_download_dir(),
        "start_minimized": False,
        "remember_last_mode": True,
        "last_mode": "video",  # video | audio
    },
    "video": {
        "quality": "best",
        "container": "mp4",
    },
    "audio": {
        "quality": "192",  # 128 | 192 | 256 | 320
        "format": "mp3",
    },
    "advanced": {
        "ytdlp_path": "",  # empty = auto-detect
        "ffmpeg_path": "",
        "max_filename_length": 80,
        "debug_logging": False,
    },
}


class Settings:
    """Persistent application settings."""

    def __init__(self) -> None:
        self._data: Dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        """Load settings from disk, merging with defaults."""
        stored = load_json(SETTINGS_FILE, {})
        self._data = self._merge(DEFAULT_SETTINGS, stored)
        logger.debug("Settings loaded")

    def save(self) -> bool:
        """Persist settings to disk."""
        ok = save_json(SETTINGS_FILE, self._data)
        if ok:
            logger.debug("Settings saved")
        return ok

    def _merge(self, defaults: Dict, stored: Dict) -> Dict:
        """Recursively merge stored values into defaults."""
        result = {}
        for key, default_val in defaults.items():
            if key in stored:
                if isinstance(default_val, dict) and isinstance(stored[key], dict):
                    result[key] = self._merge(default_val, stored[key])
                else:
                    result[key] = stored[key]
            else:
                result[key] = default_val
        return result

    def get(self, section: str, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        return self._data.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        """Set a setting value (does not auto-save)."""
        if section not in self._data:
            self._data[section] = {}
        self._data[section][key] = value

    def get_section(self, section: str) -> Dict[str, Any]:
        """Return an entire section."""
        return dict(self._data.get(section, {}))

    @property
    def download_folder(self) -> str:
        return self.get("general", "download_folder", default_download_dir())

    @download_folder.setter
    def download_folder(self, value: str) -> None:
        self.set("general", "download_folder", value)

    @property
    def last_mode(self) -> str:
        return self.get("general", "last_mode", "video")

    @last_mode.setter
    def last_mode(self, value: str) -> None:
        self.set("general", "last_mode", value)

    @property
    def audio_quality(self) -> str:
        return self.get("audio", "quality", "192")

    @audio_quality.setter
    def audio_quality(self, value: str) -> None:
        self.set("audio", "quality", value)

    @property
    def max_filename_length(self) -> int:
        return int(self.get("advanced", "max_filename_length", 80))

    @property
    def ytdlp_path(self) -> str:
        return self.get("advanced", "ytdlp_path", "") or ""

    @property
    def ffmpeg_path(self) -> str:
        return self.get("advanced", "ffmpeg_path", "") or ""
