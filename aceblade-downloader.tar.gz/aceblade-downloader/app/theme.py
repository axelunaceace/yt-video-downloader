"""Centralized theme configuration for AceBlade Downloader."""

from __future__ import annotations


class Theme:
    """Dark modern theme colors and fonts."""

    # Backgrounds
    BG = "#0B0F19"
    CARD = "#111827"
    CARD_SECONDARY = "#172033"
    CARD_HOVER = "#1E293B"
    INPUT_BG = "#0F172A"
    BORDER = "#1E293B"
    BORDER_FOCUS = "#6366F1"

    # Accents
    ACCENT = "#6366F1"
    ACCENT_HOVER = "#818CF8"
    ACCENT_MUTED = "#4F46E5"

    # Text
    TEXT = "#F8FAFC"
    TEXT_SECONDARY = "#94A3B8"
    TEXT_MUTED = "#64748B"
    TEXT_DISABLED = "#475569"

    # Status
    SUCCESS = "#22C55E"
    SUCCESS_BG = "#052E16"
    ERROR = "#EF4444"
    ERROR_BG = "#450A0A"
    WARNING = "#F59E0B"
    WARNING_BG = "#451A03"
    INFO = "#38BDF8"

    # Progress
    PROGRESS_BG = "#1E293B"
    PROGRESS_FILL = "#6366F1"

    # Fonts (Tkinter compatible)
    FONT_FAMILY = "Segoe UI"
    FONT_FALLBACK = "DejaVu Sans"
    FONT_MONO = "DejaVu Sans Mono"

    # Sizes
    FONT_TITLE = ("Segoe UI", 22, "bold")
    FONT_HEADING = ("Segoe UI", 14, "bold")
    FONT_SUBHEADING = ("Segoe UI", 12, "bold")
    FONT_BODY = ("Segoe UI", 11)
    FONT_SMALL = ("Segoe UI", 10)
    FONT_TINY = ("Segoe UI", 9)
    FONT_BUTTON = ("Segoe UI", 11, "bold")
    FONT_MONO_SMALL = ("DejaVu Sans Mono", 10)

    # Spacing
    PAD_XS = 4
    PAD_SM = 8
    PAD_MD = 12
    PAD_LG = 16
    PAD_XL = 24

    # Window
    WINDOW_BG = BG
    SETUP_WIDTH = 520
    SETUP_HEIGHT = 460
    MAIN_WIDTH = 920
    MAIN_HEIGHT = 680
    MIN_WIDTH = 780
    MIN_HEIGHT = 580

    @classmethod
    def get_font(cls, size: int = 11, bold: bool = False, mono: bool = False) -> tuple:
        """Return a font tuple with graceful fallback."""
        family = cls.FONT_MONO if mono else cls.FONT_FAMILY
        weight = "bold" if bold else "normal"
        return (family, size, weight)
